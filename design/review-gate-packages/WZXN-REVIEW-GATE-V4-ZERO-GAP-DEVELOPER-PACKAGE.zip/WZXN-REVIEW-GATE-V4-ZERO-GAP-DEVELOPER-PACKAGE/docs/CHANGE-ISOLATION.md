# Protocol v4 change isolation

The v4 remediation is one root-of-trust migration and is intentionally installed atomically under one operator-authorized maintenance CR. A partially installed state is unsafe because the normal receipt schema, standalone bootstrap, remote authorization helper, hosted dispatch authorization, publication provenance, evidence schema and static validator must agree on the same protocol/profile.

The installer therefore changes only the enumerated protected gate/harness/workflow/contract artifacts and refuses baseline drift. Product source, product tests, runner lane IDs/labels and unrelated harness behavior are outside scope.

After the v4 cutover is complete and independently bootstrap-reviewed, future work is isolated into ordinary small CRs: provider/profile tuning, evidence optimization, workflow-policy changes and bootstrap changes are not bundled merely for convenience.
