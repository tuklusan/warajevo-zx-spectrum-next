## Review protocol v4 workflow correction

This section supersedes conflicting earlier hosted acceptance/cancellation wording.

1. Every tracked mandatory review requires one active CR and matching approved preflight. `Review-Base` is mandatory and is normally a stable tag created at the committed preflight baseline. Gate/harness/governance edits additionally require `Operator-Authorized-Gate-Change: YES`.
2. CODE PASS -> required DOCUMENTATION PASS -> publish exact reviewed commit -> generate short-lived hosted authorization -> dispatch `platform-smoke` once for that exact commit -> wait for every lane to reach terminal success -> retain signed publication evidence -> TEST_ARTIFACT second opinion.
3. `platform-smoke` is protected execution and is dispatch-only. Its exact 20 lane IDs/labels are mandatory. There is no local/remote substitution for a hosted lane in publication acceptance.
4. A queued/in-progress hosted run is never cancelled or replaced by housekeeping. Housekeeping may delete only older terminal completed runs and generated workspace residue.
5. Windows 11 and macOS platform breadth is supplied by the unchanged hosted matrix; retired local-lab Windows-11/Big-Sur machines remain retired and are not exceptions/expected failures.
6. Signed publication provenance binds workflow run ID, exact commit/build ID, workflow blob, exact expected lanes, terminal jobs and artifacts. TEST_ARTIFACT verifies that provenance before semantic review.

7. Gate protocol/root-of-trust migration is applied atomically under one operator-authorized maintenance CR because partial installation would mismatch receipts, hosted authorization, evidence schema and verifier authority. After cutover, independent tuning or policy changes return to ordinary small CRs.
