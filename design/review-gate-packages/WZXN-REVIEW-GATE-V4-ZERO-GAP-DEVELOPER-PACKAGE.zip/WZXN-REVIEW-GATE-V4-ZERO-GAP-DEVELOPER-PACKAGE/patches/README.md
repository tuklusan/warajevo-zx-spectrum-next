# Patch material

`generate_exact_patches.py` creates exact unified patches against certified baseline commit
`6ba164cc125b7f2a78c58f7a3047090d530e7fa5` without modifying the checkout. It covers every
full replacement plus the deterministic edits to `invoke_remote_harness.py`, `WORKFLOW.md`,
`design/review-gate.md`, and `design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md`.

Run before applying the update:

```text
python patches/generate_exact_patches.py <WZXN-checkout> --out <output-directory>
```

The delivery also contains full replacement payload files and `apply_update.py`; patches are
review material and an alternate deterministic handoff representation, not a bypass around the
operator-authorized bootstrap process.
