#!/usr/bin/env python3
"""Emit reviewable unified patches for the certified WZXN v4 package.

Run from the extracted delivery package against a local checkout that contains the certified
baseline commit. This never edits the checkout; it reconstructs the installer's desired bytes
and writes patches to the requested output directory.
"""
from __future__ import annotations
import argparse,difflib,importlib.util,subprocess,tempfile
from pathlib import Path

PACKAGE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('wz_apply_update',PACKAGE/'apply_update.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
BASE=mod.CERTIFIED_BASELINE

def git_bytes(root:Path,path:str)->bytes:
 p=subprocess.run(['git','show',f'{BASE}:{path}'],cwd=root,check=False,capture_output=True)
 if p.returncode!=0:return b''
 return p.stdout

def text_diff(path:str,old:bytes,new:bytes)->str:
 try:o=old.decode('utf-8'); n=new.decode('utf-8')
 except UnicodeDecodeError: raise SystemExit(f'non-UTF8 patch target unsupported: {path}')
 a=f'a/{path}' if old else '/dev/null'; b=f'b/{path}'
 return ''.join(difflib.unified_diff(o.splitlines(True),n.splitlines(True),fromfile=a,tofile=b,n=5))

def desired_append_targets(repo:Path)->dict[str,bytes]:
 with tempfile.TemporaryDirectory() as td:
  root=Path(td)
  for path in ('tools/harness/invoke_remote_harness.py','design/review-gate.md','design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md','WORKFLOW.md'):
   dst=root/path; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(git_bytes(repo,path))
  mod.patch_remote(root)
  mod.append_once(root/'design/review-gate.md','## Protocol v4 authoritative correction',(PACKAGE/'docs/PROTOCOL-V4-CONTRACT-ADDENDUM.md').read_text())
  mod.append_once(root/'design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md','## Protocol v4 bootstrap/root-of-trust correction',(PACKAGE/'docs/FRESH-BOOTSTRAP-V4-ADDENDUM.md').read_text())
  mod.patch_workflow_doc(root,(PACKAGE/'docs/WORKFLOW-V4-ADDENDUM.md').read_text())
  return {p:(root/p).read_bytes() for p in ('tools/harness/invoke_remote_harness.py','design/review-gate.md','design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md','WORKFLOW.md')}

def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument('repo'); ap.add_argument('--out',default='generated-patches'); a=ap.parse_args()
 repo=Path(a.repo).resolve(); out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
 if subprocess.run(['git','cat-file','-e',f'{BASE}^{{commit}}'],cwd=repo).returncode!=0: raise SystemExit('certified baseline commit is unavailable in checkout')
 patches=[]
 desired={rel:(PACKAGE/'payload'/rel).read_bytes() for rel in mod.FULL_REPLACEMENTS}
 desired.update(desired_append_targets(repo))
 for idx,path in enumerate(sorted(desired),1):
  diff=text_diff(path,git_bytes(repo,path),desired[path])
  name=out/f'{idx:03d}-{path.replace("/","_")}.patch'; name.write_text(diff,encoding='utf-8'); patches.append(name)
 combined=out/'000-combined.patch'; combined.write_text(''.join(p.read_text() for p in patches),encoding='utf-8')
 print(combined)
 return 0
if __name__=='__main__': raise SystemExit(main())
