# WZXN External Review Gate Protocol v4 Update Package

Target certified baseline: `6ba164cc125b7f2a78c58f7a3047090d530e7fa5`  
Certified recommendation ledger: `WZXN-GATE-RECOMMENDATION-LEDGER-CERTIFIED.md`, SHA-256 `5abd88f6bc8abc22bc13968ec1ea762697d7db34c11ab94d780beadd0d1079c9`.

This package is intentionally **not self-applying**. It modifies protected gate/harness artifacts and therefore requires the project's operator-authorization/preflight process.

## Application sequence

1. Create the next tracked CR and `design/cr-preflight/CR-NNNN.md` using `docs/MIGRATION-PREFLIGHT-TEMPLATE.md`.
2. Commit that CR/preflight record **before** applying the gate update. Set `Review-Base` to that pre-change commit and record `Operator-Authorized-Gate-Change: YES` only under explicit operator authorization.
3. From the project root run:

   ```text
   python <package>/apply_update.py . --operator-authorized
   ```

   The installer rejects any protected source whose Git blob differs from the certified baseline. It writes `test-artefacts/reviewer/bootstrap-root-of-trust.local.json` and runs syntax/static checks only; it does not build or test the product.
4. Inspect the intended-only diff, update the CR review map/hashes, commit the candidate to the maintenance ref, and run the **standalone** bootstrap gate, not the normal gate:

   ```text
   python tools/reviewer/legacy_bootstrap_gate.py \
     --cr CR-NNNN --base <Review-Base> --head HEAD \
     --requirements design/review-gate.md \
     --requirements design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md \
     --root-of-trust-record test-artefacts/reviewer/bootstrap-root-of-trust.local.json
   ```

5. Apply any bootstrap finding as a new immutable candidate and repeat the complete bootstrap review. Never use scoped bootstrap review as authorization.
6. After bootstrap PASS, use the protected maintenance harness path and complete the project-prescribed documentation/closure sequence.

## Review map v4

Normal CODE/DOCUMENTATION review maps remain JSON objects with a `links` array. Link IDs must be unique. Every link contains an exact requirement source/full SHA/range and related original path/full SHA/range. CODE may add `related.snapshot` (`head` or `base`) and a `prior` object with its own path/hash/range. Distinct requirement excerpts in one file receive distinct stable IDs.

CODE map coverage is checked against the **complete Git change universe at changed-hunk granularity**. Every changed hunk, deletion, rename/copy side, mode/type change, and acceptance-relevant non-text change must be represented or explicitly fail closed. DOCUMENTATION links use `related.role: "document"` for members of the exact reviewed `--path` set and `related.role: "context"` for immutable implementation/supporting context; document-role coverage must exactly equal the command's `--path` set. Oversized semantic units are rejected instead of character-sharded.

## NVIDIA reasoning profile

`tools/reviewer/review-profile-v4.json` is the canonical accepted profile:

- health / pure formatting: `none`;
- CODE/DOCUMENTATION/TEST discovery: `medium`;
- cross-unit CODE integration: `high`;
- hostile falsification: `high`;
- evidence-backed adjudication: `high`.

Every thinking phase reserves final-answer capacity (`reasoning_budget < max_tokens`). HTTP 202 is polled through the documented request-ID status endpoint. No `max` reasoning-effort alias exists.

## Hosted authorization

Create one random secret of at least 32 bytes and store the **same value**:

- locally as environment variable `WZXN_HOSTED_GATE_HMAC_KEY` when generating/validating private authorizations and TEST publication provenance;
- in the GitHub repository Actions secret named `WZXN_HOSTED_GATE_HMAC_KEY`.

After CODE PASS, DOCUMENTATION PASS, and publication of the exact reviewed commit to `origin/main`, run locally:

```text
python tools/harness/make_hosted_authorization.py
```

Pass the returned `authorization_payload` and `authorization_signature` to a manual `platform-smoke` workflow dispatch for that exact commit. The product matrix cannot start until the authorization job verifies them.

The 20 matrix lane IDs and labels are unchanged. `platform-smoke` no longer has push/PR product-execution triggers, does not cancel live runs, nests Sokol evidence inside the canonical lane bundle, validates all 20 results, and produces a signed `platform-publication-<run-id>` artifact.

Download/extract that publication artifact as the TEST evidence root and run TEST_ARTIFACT with the exact run ID, head SHA as build ID, and run ID as publication ID. TEST validates the unresolved-Fuse baseline from the **tested commit Git object**, not a later working tree. Large requirement sources use bounded requirement excerpts through the review map while the full authority source remains hash-bound.

## Important fail-closed changes

- Protocols below v4 no longer authorize remote execution.
- Normal CODE review refuses changes to protected gate/governance paths with `BOOTSTRAP_REQUIRED`.
- Material discovery uncertainty/evidence requests return INCONCLUSIVE rather than PASS.
- Malformed serious candidates cannot be silently discarded.
- Candidate proof is structured and evidence-ID bound.
- Non-thinking compact fallback has no semantic review authority.
- DOCUMENTATION is tied to the exact CODE-reviewed commit.
- TEST uses signed hosted provenance, exact embedded lane IDs, structural fail-closed validation, artifact classification, and exact bounded retrieval.
- One atomic global lock prevents concurrent reviewer packets and does not expire a live one-hour review at 15 minutes.

## Validation

`tools/validate_review_gate_v4.py` is invoked by both local Git hooks and `repository-gates.yml`. It checks protocol/profile drift, unsupported reasoning modes, bootstrap independence, exact hosted lane IDs/order, non-cancellation, protected-workflow trigger policy, and operator-authorized preflight state for protected edits.

The update package's own pre-delivery certification is recorded under `audit/` and is independent of project product tests.

## Provider capability qualification

`tools/reviewer/probe_provider_capabilities.py` is deliberately non-authoritative. Run it only when the exact hosted NVIDIA backend/profile changes or structured-output capability needs requalification. It records a private result and never changes review authority automatically. Protocol v4 remains fail-closed with deterministic application-schema validation if stronger hosted schema-constrained output has not been qualified.

## Package certification

`apply_update.py` refuses an uncertified package. Final delivery contains `PACKAGE-MANIFEST.json` plus `CERTIFICATION.json`; the latter binds the frozen application tree and records two consecutive full zero-gap audits against the certified 92-item ledger. Audit reports are retained separately and are not allowed to mutate the certified application tree between the two passes.
