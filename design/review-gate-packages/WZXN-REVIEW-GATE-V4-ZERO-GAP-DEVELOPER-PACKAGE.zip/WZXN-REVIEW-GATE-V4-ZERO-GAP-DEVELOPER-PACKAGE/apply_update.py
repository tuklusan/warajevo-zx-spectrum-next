#!/usr/bin/env python3
"""Apply the WZXN protocol-v4 review-gate remediation to the certified baseline.

This installer deliberately edits no CR/tracker record. The operator must create/commit the
active CR and approved preflight first, using docs/MIGRATION-PREFLIGHT-TEMPLATE.md.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, re, shutil, subprocess, sys
from pathlib import Path

CERTIFIED_BASELINE="6ba164cc125b7f2a78c58f7a3047090d530e7fa5"
LEDGER_SHA256="5abd88f6bc8abc22bc13968ec1ea762697d7db34c11ab94d780beadd0d1079c9"
EXPECTED_BLOBS={
 "tools/reviewer/review_gate.py":"ec19ec384a0f079cab54a5bffdc86b8ddd7b879d",
 "tools/reviewer/legacy_bootstrap_gate.py":"46097d88a41b089c5967fd5c220a58c9ae87706a",
 "tools/harness/invoke_remote_harness.py":"4e9a0159e6a6860a5ca09ad054b249815d038910",
 "tools/harness/verify_platform_evidence.py":"5fbe42b534472a7a7d4b52e3d12668a3c6031086",
 "tools/harness/cleanup-hosted-runner-state.sh":"53bf56f6cedfa0b68710ae975dace58fdfbffd79",
 ".github/workflows/platform-smoke.yml":"6578a09c5dd77d2b6834bbf7c86c2b81945beb24",
 ".github/workflows/repository-gates.yml":"5ce606c75abe5a8f3e053ea8c888f276242aa61f",
 ".githooks/pre-commit":"aa319efa6a4de498c305ca5f7807c068e1e704d7",
 ".githooks/pre-push":"aa319efa6a4de498c305ca5f7807c068e1e704d7",
 "design/review-gate.md":"2c0de8aeba428819bf36af8a94846843b3dc44c0",
 "design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md":"12b375c16d1372257428736f7b00454e82ce68b7",
 "WORKFLOW.md":"0daa69fd45b2f8638a682ab3709f827e67434884",
}
FULL_REPLACEMENTS=(
 "tools/reviewer/review_gate.py","tools/reviewer/legacy_bootstrap_gate.py","tools/reviewer/review-profile-v4.json","tools/reviewer/probe_provider_capabilities.py",
 "tools/harness/verify_platform_evidence.py","tools/harness/evidence_schema_v2.py","tools/harness/cleanup-hosted-runner-state.sh","tools/harness/review_authority_v4.py",
 "tools/harness/hosted_gate_authority.py","tools/harness/make_hosted_authorization.py","tools/harness/verify_hosted_authorization.py",
 "tools/harness/make_publication_manifest.py","tools/validate_review_gate_v4.py",
 ".github/workflows/platform-smoke.yml",".github/workflows/repository-gates.yml",".githooks/pre-commit",".githooks/pre-push",
)

def run(root:Path,*args:str)->str:
 return subprocess.run(["git",*args],cwd=root,check=True,capture_output=True,text=True).stdout.strip()
def blob(root:Path,path:str)->str: return run(root,"hash-object","--",path)
def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def replace_function(text:str,name:str,replacement:str)->str:
 tree=ast.parse(text); target=next((n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name),None)
 if target is None: raise SystemExit(f"baseline function not found: {name}")
 lines=text.splitlines(keepends=True); start=target.lineno-1; end=target.end_lineno
 return "".join(lines[:start])+replacement.rstrip()+"\n\n"+"".join(lines[end:])
def verify_package(package:Path)->dict:
 manifest_path=package/"PACKAGE-MANIFEST.json"; cert_path=package/"CERTIFICATION.json"
 if not manifest_path.is_file() or not cert_path.is_file(): raise SystemExit("package is not zero-gap certified")
 raw=manifest_path.read_bytes(); manifest=json.loads(raw); cert=json.loads(cert_path.read_text(encoding="utf-8"))
 if manifest.get("schema_version")!=1 or manifest.get("baseline_commit")!=CERTIFIED_BASELINE or manifest.get("ledger_sha256")!=LEDGER_SHA256:
  raise SystemExit("package manifest authority mismatch")
 records=manifest.get("files")
 if not isinstance(records,list) or not records: raise SystemExit("package manifest file list is missing")
 canonical=[]; seen=set()
 for rec in records:
  if not isinstance(rec,dict) or not isinstance(rec.get("path"),str) or rec["path"] in seen: raise SystemExit("package manifest record malformed/duplicate")
  seen.add(rec["path"]); f=package/rec["path"]
  if not f.is_file(): raise SystemExit(f"package file missing: {rec['path']}")
  data=f.read_bytes(); actual=sha(data)
  if actual!=rec.get("sha256") or len(data)!=rec.get("bytes"): raise SystemExit(f"package file changed after certification: {rec['path']}")
  canonical.append({"path":rec["path"],"sha256":actual,"bytes":len(data)})
 tree=sha(json.dumps(canonical,ensure_ascii=True,separators=(",",":"),sort_keys=True).encode())
 if tree!=manifest.get("tree_sha256"): raise SystemExit("package tree identity mismatch")
 if (cert.get("schema_version")!=1 or cert.get("manifest_sha256")!=sha(raw) or cert.get("tree_sha256")!=tree
     or cert.get("baseline_commit")!=CERTIFIED_BASELINE or cert.get("ledger_sha256")!=LEDGER_SHA256
     or cert.get("consecutive_zero_gap_audits")!=2 or cert.get("result")!="ZERO_GAPS"):
  raise SystemExit("package zero-gap certification is absent or mismatched")
 return {"manifest_sha256":sha(raw),"tree_sha256":tree,"certification_sha256":sha(cert_path.read_bytes())}

def active_preflight(root:Path)->tuple[str,str]:
 tracker=json.loads((root/"issues/change-requests.json").read_text(encoding="utf-8")); active=[x for x in tracker.get("change_requests",[]) if x.get("status")=="in_progress"]
 authorized=[]
 for item in active:
  cr=item.get("cr_number"); p=root/"design"/"cr-preflight"/f"{cr}.md"
  if not p.is_file(): continue
  text=p.read_text(encoding="utf-8")
  m=re.search(r"(?im)^Review-Base:\s*(\S+)\s*$",text)
  if ("Status: APPROVED_FOR_IMPLEMENTATION" in text and "## Zero-Gap Exit Scan" in text and m and
      re.search(r"(?im)^Operator-Authorized-Gate-Change:\s*YES\s*$",text)):
   authorized.append((cr,m.group(1)))
 if len(authorized)!=1: raise SystemExit("installer requires exactly one active approved operator-authorized gate-change CR/preflight")
 cr,base=authorized[0]
 if run(root,"rev-parse",f"{base}^{{commit}}")!=run(root,"rev-parse","HEAD"):
  raise SystemExit("active preflight Review-Base must resolve to current pre-update HEAD")
 return cr,base
def patch_remote(root:Path)->None:
 p=root/"tools/harness/invoke_remote_harness.py"; text=p.read_text(encoding="utf-8")
 marker="from forward_syslog import forward_tree\n"
 if "from review_authority_v4 import" not in text:
  if marker not in text: raise SystemExit("remote harness import anchor changed")
  text=text.replace(marker,marker+"from review_authority_v4 import validate_code_receipt, validate_bootstrap_receipt\n",1)
 text=replace_function(text,"validate_review_authority",'''def validate_review_authority(root: Path, receipt: dict) -> None:\n    # Protocol-v4 authority is strict; legacy receipts never authorize execution.\n    validate_code_receipt(root, receipt)''')
 text=replace_function(text,"require_code_review_pass",'''def require_code_review_pass(root: Path) -> None:\n    receipt_path = root / "test-artefacts" / "reviewer" / "code-pass.json"\n    try:\n        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))\n    except (OSError, json.JSONDecodeError) as exc:\n        raise SystemExit("remote smoke blocked: no valid private CODE PASS receipt") from exc\n    validate_code_receipt(root, receipt)''')
 text=replace_function(text,"require_bootstrap_maintenance_pass",'''def require_bootstrap_maintenance_pass(root: Path, cr_number: str, published_ref: str) -> None:\n    if not MAINTENANCE_REF.fullmatch(published_ref) or cr_number not in published_ref:\n        raise SystemExit("remote smoke blocked: bootstrap maintenance ref is invalid")\n    receipt_path = root / "test-artefacts" / "reviewer" / "bootstrap-pass.json"\n    try:\n        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))\n    except (OSError, json.JSONDecodeError) as exc:\n        raise SystemExit("remote smoke blocked: bootstrap PASS receipt is missing or invalid") from exc\n    validate_bootstrap_receipt(root, receipt, cr_number, published_ref)''')
 ast.parse(text); p.write_text(text,encoding="utf-8",newline="\n")
def append_once(path:Path,heading:str,content:str)->None:
 text=path.read_text(encoding="utf-8")
 if heading not in text: path.write_text(text.rstrip()+"\n\n"+content.strip()+"\n",encoding="utf-8",newline="\n")
def patch_workflow_doc(root:Path,addendum:str)->None:
 p=root/"WORKFLOW.md"; text=p.read_text(encoding="utf-8")
 text=text.replace("and every configured hosted macOS lane should be exercised when capacity permits.","and every configured hosted lane is mandatory for publication acceptance.")
 old=("The hosted matrix has a pre-matrix deep-housekeeping gate. It may cancel and\n"
     "delete only older `platform-smoke` workflow runs for the same ref; deleting the\n"
     "run also removes its temporary Actions artifacts without a per-artifact API\n"
     "request storm. It must preserve the current run and all committed source,\n"
     "guidance, and retained evidence. Every matrix lane also clears only generated\n"
     "build/test residue from its checked-out workspace before execution using\n"
     "workspace-only mode; queued or slow jobs in the current run remain valid and\n"
     "must still be awaited.\n")
 new=("The hosted matrix has a pre-matrix deep-housekeeping gate. It may delete only\n"
     "older terminal completed `platform-smoke` runs for the same ref; it MUST NOT\n"
     "cancel, replace, or delete a queued/in-progress run. Every matrix lane clears\n"
     "only generated workspace residue before execution.\n")
 if old not in text: raise SystemExit("WORKFLOW housekeeping contract anchor changed")
 text=text.replace(old,new,1)
 pattern=re.compile(r"Cross-platform macOS acceptance is architecture-based, not count-based\..*?before acceptance\.\n",re.S)
 replacement=("Hosted publication acceptance is exact-matrix based: all 20 configured lane IDs must reach terminal `success` for the exact commit. "
              "Intel and ARM macOS lanes remain explicitly required within that exact set. Local or remote lab evidence supplements diagnosis but never substitutes for a hosted lane.\n")
 text,n=pattern.subn(replacement,text,count=1)
 if n!=1: raise SystemExit("WORKFLOW macOS acceptance anchor changed")
 if "## Review protocol v4 workflow correction" not in text: text=text.rstrip()+"\n\n"+addendum.strip()+"\n"
 p.write_text(text,encoding="utf-8",newline="\n")
def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument("project_root",nargs="?",default="."); ap.add_argument("--operator-authorized",action="store_true"); a=ap.parse_args()
 if not a.operator_authorized: raise SystemExit("refusing gate surgery without --operator-authorized")
 root=Path(a.project_root).resolve(); package=Path(__file__).resolve().parent; payload=package/"payload"
 package_identity=verify_package(package)
 if run(root,"rev-parse","--is-inside-work-tree")!="true": raise SystemExit("project_root is not a Git repository")
 # Only CR/tracker/preflight work may differ; every protected implementation byte must still be the certified baseline.
 for path,expected in EXPECTED_BLOBS.items():
  if not (root/path).is_file() or blob(root,path)!=expected: raise SystemExit(f"certified baseline mismatch before install: {path}")
 cr,review_base=active_preflight(root)
 for rel in FULL_REPLACEMENTS:
  src=payload/rel; dst=root/rel
  if not src.is_file(): raise SystemExit(f"package payload missing: {rel}")
  dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
 patch_remote(root)
 append_once(root/"design/review-gate.md","## Protocol v4 authoritative correction",(package/"docs/PROTOCOL-V4-CONTRACT-ADDENDUM.md").read_text())
 append_once(root/"design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md","## Protocol v4 bootstrap/root-of-trust correction",(package/"docs/FRESH-BOOTSTRAP-V4-ADDENDUM.md").read_text())
 patch_workflow_doc(root,(package/"docs/WORKFLOW-V4-ADDENDUM.md").read_text())
 # One-time private root of trust for the standalone bootstrap replacement.
 rot=root/"test-artefacts"/"reviewer"/"bootstrap-root-of-trust.local.json"; rot.parent.mkdir(parents=True,exist_ok=True)
 rot.write_text(json.dumps({"schema_version":1,"project_id":"github.com/tuklusan/warajevo-zx-spectrum-next","cr_number":cr,
   "baseline_commit":run(root,"rev-parse",f"{review_base}^{{commit}}"),"new_bootstrap_sha256":sha((root/"tools/reviewer/legacy_bootstrap_gate.py").read_bytes()),
   "ledger_sha256":LEDGER_SHA256,"package_manifest_sha256":package_identity["manifest_sha256"],
   "package_tree_sha256":package_identity["tree_sha256"],"certification_sha256":package_identity["certification_sha256"],
   "operator_approved":True},indent=2,sort_keys=True)+"\n",encoding="utf-8")
 # Syntax/static checks only; installer intentionally runs no product build/test.
 for rel in ("tools/reviewer/review_gate.py","tools/reviewer/legacy_bootstrap_gate.py","tools/harness/review_authority_v4.py","tools/harness/verify_platform_evidence.py","tools/validate_review_gate_v4.py"):
  ast.parse((root/rel).read_text(encoding="utf-8"))
 print(json.dumps({"status":"installed","cr_number":cr,"review_base":review_base,"certified_source_baseline":CERTIFIED_BASELINE,
                   "root_of_trust_record":rot.relative_to(root).as_posix()},sort_keys=True))
 return 0
if __name__=="__main__": raise SystemExit(main())
