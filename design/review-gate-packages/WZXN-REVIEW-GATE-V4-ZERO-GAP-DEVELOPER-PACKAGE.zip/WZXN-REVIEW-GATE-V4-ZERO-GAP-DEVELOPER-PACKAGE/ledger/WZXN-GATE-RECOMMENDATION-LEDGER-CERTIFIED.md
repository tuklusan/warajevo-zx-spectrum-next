# WZXN External Review Gate — Zero-Gap Recommendation Ledger

**Audit date:** 2026-09-09  
**Repository:** `tuklusan/warajevo-zx-spectrum-next`  
**Pinned current-main baseline:** `6ba164cc125b7f2a78c58f7a3047090d530e7fa5`  
**Normal gate blob observed at that commit:** `ec19ec384a0f079cab54a5bffdc86b8ddd7b879d`  
**Purpose:** correctness and optimization audit of the WZXN external-review gate, including the user's requirement to enable model reasoning for prompts where it materially improves correctness.  
**Priority order:** correctness → fail-closed precision → independent trust → provider correctness → token/call/latency optimization.  
**Repository modification status:** recommendation only; this audit did not modify WZXN.

## Executive finding

The architecture remains fundamentally sound in intent: immutable candidate identity, candidate-versus-confirmed-finding separation, hostile falsification, deterministic synthesis, bounded evidence expansion, private receipts, and a compact TEST evidence goal are all good choices.

However, current `main` contains **several P0 gate-integrity regressions**, especially in the newly mandatory requirement-linked CODE/DOCUMENTATION packet path. The most urgent are:

1. valid linked CODE source findings can be deterministically rejected because linked packets have no tracked-path/source-location universe;
2. linked CODE PASS snapshot IDs are incompatible with the remote harness's still-required diff snapshot format;
3. a review map can omit changed/required material because completeness of the full evidence universe is not proven;
4. same-file requirement excerpts collide in authority handling and can also create remote receipt rejection;
5. TEST artifact completeness/status interpretation remains inconsistent with the canonical producer schema;
6. bootstrap independence is still violated;
7. the normal gate can age out a healthy one-hour review lock after fifteen minutes;
8. substantive falsification/adjudication still run with reasoning disabled despite both the tracked contract and the model's capabilities.

Optimization should therefore follow this rule:

> **Bind 100% of the authoritative evidence universe deterministically; transmit only the minimum sufficient semantic evidence; retrieve exact bounded evidence on demand; use stronger reasoning only for semantic phases where it adds correctness; fail closed whenever material evidence remains unavailable.**

## Official NVIDIA model/API facts used in this ledger

The audit cross-checked the exact configured hosted model `nvidia/nemotron-3-ultra-550b-a55b` against current NVIDIA documentation.

- Model-specific hosted inference API: `https://docs.api.nvidia.com/nim/reference/nvidia-nemotron-3-ultra-550b-a55b-infer`
- Model page/examples: `https://docs.api.nvidia.com/nim/reference/nvidia-nemotron-3-ultra-550b-a55b`
- Thinking budget control: `https://docs.nvidia.com/nim/large-language-models/1.15.0/thinking-budget-control.html`
- Structured generation: `https://docs.nvidia.com/nim/large-language-models/1.15.0/structured-generation.html`

Provider facts relied upon:

- hosted Ultra `reasoning_effort`: `none`, `medium`, `high`;
- `reasoning_budget` is separate from total `max_tokens`;
- model-specific `max_tokens` range is 1–32768;
- HTTP 202 means result pending and should be polled using `requestId`;
- medium effort is intended as the efficient reasoning mode; high enables full reasoning;
- a reasoning budget must leave room for the final answer (`max_tokens > reasoning_budget`);
- structured-generation and reasoning-budget combinations must be capability-verified for the exact serving backend rather than assumed from generic NIM documentation.

## Relevant current repository components

- `tools/reviewer/review_gate.py` — normal CODE/DOCUMENTATION/TEST_ARTIFACT gate and NVIDIA client.
- `tools/reviewer/legacy_bootstrap_gate.py` — retained maintenance/bootstrap reviewer.
- `tests/test_review_gate.py` — gate protocol/regression tests.
- `tools/harness/invoke_remote_harness.py` — consumes normal/bootstrap PASS receipts before local-lab execution.
- `tests/test_remote_harness_gate.py` — remote authorization regression tests.
- `tools/harness/verify_platform_evidence.py` — produces and verifies lane evidence manifests.
- `tools/harness/run_fuse_ed_platform.py` / `run_fuse_ed_corpus.py` — pinned Fuse evidence producer and manifest semantics.
- `.github/workflows/platform-smoke.yml` — exact 20-lane hosted matrix and publication gate.
- `tools/harness/cleanup-hosted-runner-state.sh` — hosted run cleanup/cancellation policy.
- `tools/validate_project_gates.py`, `.githooks/pre-commit`, `.githooks/pre-push`, `.github/workflows/repository-gates.yml` — static enforcement.
- `design/review-gate.md`, `design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md`, `WORKFLOW.md` — governing contracts.
- `tools/harness/harness-lock.json` — operator-authorization boundary for harness/gate changes.

## Recommendation ledger

### ZG-001 — P0 — Linked CODE packet / false PASS

**Finding.** `linked_packet()` returns a CODE `ReviewPacket` with `head_sha`/`base_sha` but leaves `tracked_paths` empty, while `deterministic_filter()` rejects any CODE candidate whose source path is not in `tracked_paths`. The linked packet records are `linked/<id>.json`, not `head/<source>`. A real source-located candidate can therefore be deterministically discarded and the review can fall through to PASS.

**Recommendation.** Populate the immutable complete tracked-path/change universe for linked CODE packets and make candidate-location validation understand linked source/range bindings. Add a regression where discovery reports a valid HIGH at the mapped source line and prove it reaches falsification, not deterministic rejection.

**Evidence anchor.** `tools/reviewer/review_gate.py`: `linked_packet`, `deterministic_filter`, `candidate_location_valid`; current tests do not exercise a linked packet through the full candidate pipeline.

### ZG-002 — P0 — CODE receipt / remote authorization

**Finding.** Linked CODE snapshot IDs are emitted as `git:<base>..<head>:linked:<packet-hash>`, but `invoke_remote_harness.py::require_code_review_pass()` still requires `git:<base>..<head>:sha256:<80-line-diff-hash>`. A legitimate linked CODE PASS receipt is therefore unusable for protected remote execution.

**Recommendation.** Preserve two separately named identities: the canonical public code snapshot/diff identity required by the remote harness, and the semantic review-map/packet identity. Bind both in the receipt and verify both; do not overload one field.

**Evidence anchor.** `review_gate.py::linked_packet`; `invoke_remote_harness.py::require_code_review_pass`; `design/review-gate.md` still states the public `:sha256:<diff>` form is retained for compatibility.

### ZG-003 — P0 — Minimal packet completeness

**Finding.** The mandatory review map can select only chosen requirement/source ranges. `linked_packet()` validates internal hashes and ranges, but it does not prove that every changed path, deletion, rename, non-text change, or current acceptance requirement has a mapped/dispositioned representation. An omitted change can therefore be absent from semantic review without forcing INCONCLUSIVE.

**Recommendation.** Reintroduce a complete deterministic local change universe (status/path/mode/object/hash/classification) and a map-coverage ledger. Every changed item and current requirement must be mapped, explicitly dispositioned as non-semantic/not-applicable with evidence, or make the review INCONCLUSIVE. Transmit compactly; do not retransmit whole files by default.

**Evidence anchor.** `review_gate.py::linked_packet`; `design/review-gate.md` claims Minimal BUT Sufficient+Accurate, but current code establishes integrity of selected links, not completeness of the universe.

### ZG-004 — P0 — Requirement identity collision

**Finding.** `minimal_requirements` permits multiple excerpts from the same requirement source, but `requirement_map()` keys solely by `source`. Later excerpts overwrite earlier excerpts. A candidate citing an earlier valid excerpt from the same file can be rejected as if the quote were non-authoritative.

**Recommendation.** Give each authoritative requirement excerpt a stable identity such as `(source, full_sha256, start, end, excerpt_sha256)` and make candidates cite that identity. Never collapse distinct excerpts merely because they share a file path.

**Evidence anchor.** `linked_packet`, `requirement_map`, `deterministic_filter`.

### ZG-005 — P0 — Receipt authority / duplicate requirements

**Finding.** Multiple mapped requirement excerpts from the same source also produce duplicate `requirement_sources` entries in the CODE receipt. The remote harness explicitly rejects duplicate requirement-source bindings, so a common multi-link map can create a PASS receipt that cannot authorize execution.

**Recommendation.** Canonicalize receipt authority by unique full sources while separately binding the exact reviewed excerpt identities/map hash. Add a two-excerpts-from-one-file end-to-end receipt/remote authorization test.

**Evidence anchor.** `review_gate.py::minimal_requirements` / receipt writer; `invoke_remote_harness.py::validate_review_authority`.

### ZG-006 — P0 — Private scope authority regression

**Finding.** CODE main-flow appends private scope to the initially loaded requirements, then overwrites `requirements` with `linked_packet()`'s minimal requirements. The receipt still records `scope_private_source`. The remote harness requires that private source to appear in `requirement_sources`, so a CODE PASS using `--scope-file` can be rejected unless the review map happens to duplicate the private scope as a requirement.

**Recommendation.** Bind private scope independently and deterministically in the receipt/remote verifier, or guarantee it is preserved in canonical authority records without relying on map author behavior. Add the documented `--scope-file + --review-map` command as an end-to-end fixture.

**Evidence anchor.** `review_gate.py::main`; `invoke_remote_harness.py::validate_review_authority`; documented CODE command.

### ZG-007 — P0 — DOCUMENTATION snapshot scope

**Finding.** `DOCUMENTATION` still requires one or more `--path` arguments, but the linked-packet branch does not use those paths to construct or validate the reviewed document set. The review map alone selects content, so a caller can name document A while the map reviews document B.

**Recommendation.** Bind the exact requested document set into the snapshot and require complete map coverage of that set. Reject maps that omit requested documents or point outside the authorized document/context roots.

**Evidence anchor.** `review_gate.py::main`, `linked_packet`.

### ZG-008 — P0 — Deleted-file review

**Finding.** `linked_packet()` calls `resolve_inside(root, related_path)` before CODE Git-object handling, which requires the related file to exist in the current working tree. A deleted file cannot be represented as the related source, so deletions are not supported by the mandatory linked CODE path.

**Recommendation.** Support deletion records explicitly from the base tree, including original path/mode/object/hash and bounded base excerpts/diff. Add deletion-only and delete+replacement fixtures.

**Evidence anchor.** `review_gate.py::linked_packet`, `resolve_inside`.

### ZG-009 — P1 — Rename/copy prior identity

**Finding.** Linked CODE prior context requires `prior.path == related_path` and reads the same path from the base commit. True renames/copies can have a different base path, so old/new identity cannot be represented faithfully.

**Recommendation.** Represent `base_path` and `head_path` separately, derive rename/copy status from Git, and bind prior/current excerpts to their actual object paths.

**Evidence anchor.** `review_gate.py::linked_packet` prior handling.

### ZG-010 — P0 — Opaque/non-text CODE changes

**Finding.** The old complete CODE packet classified binaries, images, symlinks and gitlinks. The mandatory linked packet decodes requirement/related content as UTF-8 and has no complete non-text change manifest. A non-text change can disappear from the review universe if it is not mapped.

**Recommendation.** Keep the complete immutable Git change manifest for all modes/types. For non-text semantics, require approved deterministic extraction/description where acceptance-relevant or return INCONCLUSIVE; never silently omit the change.

**Evidence anchor.** `review_gate.py::linked_packet` versus `classify_bytes`/legacy `code_packet`; `design/review-gate.md` non-text policy.

### ZG-011 — P1 — Review-map identifier integrity

**Finding.** Review-map link IDs are not proven unique before records named `linked/<id>.json` are emitted. Duplicate IDs can create duplicate record names while the manifest contains multiple entries, creating ambiguous record lookup/diagnostics.

**Recommendation.** Require unique normalized IDs and reject duplicate or path-unsafe identifiers before packet construction.

**Evidence anchor.** `load_review_map`, `linked_packet`.

### ZG-012 — P1 — Requirement CLI authority drift

**Finding.** `--requirements` remains required and is parsed, but normal CODE/DOCUMENTATION then replace those records with requirement excerpts obtained from `--review-map`. The actual authority can differ from the authority the operator explicitly passed.

**Recommendation.** Choose one unambiguous contract: either review-map requirement entries must be a verified subset of the explicitly supplied authoritative sources, or remove the misleading CLI authority input. For mandatory reviews, cross-check the map against CR `source_authority` and universal baseline.

**Evidence anchor.** `review_gate.py::main`; `load_cr_scope`; `linked_packet`.

### ZG-013 — P0 — Requirement-manifest semantic binding

**Finding.** `requirements_manifest_hash()` hashes only `source` and full-source SHA-256. It does not bind the reviewed excerpt range/hash. Two materially different excerpt selections from the same unchanged source can therefore have the same requirement-manifest identity.

**Recommendation.** Include exact excerpt identity (range + excerpt hash, or stable requirement ID) in the review authority manifest and receipt. The remote verifier should validate the reviewed authority profile, not merely full-file hashes.

**Evidence anchor.** `requirements_manifest_hash`; linked requirement records.

### ZG-014 — P1 — Map semantic-sufficiency overclaim

**Finding.** The tracked contract says the packet builder proves requirement text, implementation/document excerpt and prior diff refer to the same CR intent. The builder can prove byte/range consistency, but it cannot prove natural-language semantic sufficiency or that the chosen ranges are the right ones.

**Recommendation.** Separate deterministic integrity from semantic sufficiency in the contract. Deterministically prove universe coverage and byte provenance; require the reviewer to judge semantic sufficiency and request bounded context when necessary.

**Evidence anchor.** `design/review-gate.md` Requirement-linked review packets; `linked_packet`.

### ZG-015 — P1 — Linked CODE context expansion

**Finding.** Even after fixing candidate validation, PATH/SYMBOL expansion is not wired to the linked packet's complete immutable source universe. `linked_packet()` leaves `tracked_paths` empty and records no `head/<path>` content, so deterministic navigation is impaired.

**Recommendation.** Populate immutable tracked-path metadata and let PATH/SYMBOL resolve from the reviewed Git head with policy checks. Preserve minimum transmission by fetching only requested bounded context.

**Evidence anchor.** `linked_packet`; `resolve_context_request`; `location_symbol_request`.

### ZG-016 — P1 — Context compaction loses the requested location

**Finding.** `compact_falsification_resolution()` compacts generic PATH/SYMBOL returned content around line 1 rather than the actual requested/matched line. A model-requested symbol or deep-path context can lose the exact evidence it asked for before falsification.

**Recommendation.** Carry source line/range metadata in every context resolution and compact around that range/match. Test a symbol at a late line in a large file.

**Evidence anchor.** `compact_falsification_resolution`, `resolve_context_request`.

### ZG-017 — P0 — Pre-candidate uncertainty/evidence requests

**Finding.** Discovery schema accepts top-level `evidence_requests` and `uncertainties`, but `perform_review()` only consumes `candidates`. A clean candidate list with a material uncertainty/request can fall through toward PASS.

**Recommendation.** Resolve bounded pre-candidate requests in a controlled discovery-expansion cycle; any unresolved material uncertainty must make the review INCONCLUSIVE. Distinguish informational uncertainty from acceptance-relevant uncertainty in schema.

**Evidence anchor.** `discovery_schema_valid`; `perform_review`.

### ZG-018 — P0 — Malformed serious candidates

**Finding.** Discovery schema deliberately accepts any dict in `candidates`; malformed candidate objects are later deterministically rejected. If the model attempted to report a serious defect but missed one required field, rejecting it is not evidence that the code is clean.

**Recommendation.** Require candidate schema validity at discovery response validation or perform bounded schema repair. If a candidate remains malformed after repair, return INCONCLUSIVE rather than deleting the suspicion and allowing PASS.

**Evidence anchor.** `discovery_schema_valid`; `deterministic_filter`; current test explicitly expects malformed-candidate rejection.

### ZG-019 — P0 — Decision-state algebra

**Finding.** `decision_schema_valid()` does not enforce the full semantic mapping between decision and evidence conclusion. For example, a rejection can be paired with inconclusive evidence even though the prompt says missing evidence must be UNRESOLVED.

**Recommendation.** Enforce deterministic algebra: CONFIRMED=>VIOLATION+BLOCKER/HIGH; REJECTED=>COMPLIANCE; NON_BLOCKING=>real but below gate threshold with a compatible evidence conclusion; UNRESOLVED=>INCONCLUSIVE. Apply equivalent rules to adjudication.

**Evidence anchor.** `decision_schema_valid`; adjudication validator; falsification prompt.

### ZG-020 — P0 — Falsifier proof provenance

**Finding.** A CONFIRMED decision needs a non-empty `proof` string, but the harness does not prove that the cited proof actually exists in the immutable evidence supplied to falsification.

**Recommendation.** Make proof structured and provenance-bound (source/range/hash or evidence-record ID) and validate it deterministically before a confirmed BLOCKER/HIGH can be synthesized.

**Evidence anchor.** `decision_schema_valid`; `make_blocker`; `falsification_evidence`.

### ZG-021 — P0 — Compact fallback authority

**Finding.** On single-candidate falsification truncation, the gate retries with a compact non-thinking call and then accepts that decision through the normal authority path. The contract explicitly says the fallback never supplies review authority by itself.

**Recommendation.** Treat compact fallback only as a formatting/liveness recovery over semantics already established, or require a subsequent authoritative thinking-enabled confirmation. A compact fallback must never independently create or clear a blocker.

**Evidence anchor.** `perform_review` FALSIFICATION-COMPACT branch; `design/review-gate.md`.

### ZG-022 — P0 — Global review lock duration

**Finding.** `STALE_LOCK_SECONDS` is 900 seconds while normal reviews may legitimately run for 3600 seconds. A healthy review lasting over 15 minutes can be declared stale and another review started.

**Recommendation.** Use lease renewal/heartbeat tied to the live process and deadline, with stale threshold safely beyond the maximum lease or explicit expiry. Never age out an actively heartbeating review.

**Evidence anchor.** `STALE_LOCK_SECONDS`; `active_review_is_stale`; one-hour review contract.

### ZG-023 — P0 — Global review lock race

**Finding.** `require_no_parallel_review()` scans existing locks and `acquire_review_lock()` later creates a snapshot-specific file. Two processes for different snapshots can both observe no lock and successfully create different files.

**Recommendation.** Use one repository-global atomic lock primitive (single exclusive file/OS lock) and store review metadata inside it. Add a true concurrent-process race test.

**Evidence anchor.** `require_no_parallel_review`; `acquire_review_lock`.

### ZG-024 — P0 — CR/preflight gate enforcement

**Finding.** `WORKFLOW.md` requires tracker and preflight to identify the same active CR before each review. `review_gate.py` loads the CR tracker but does not validate `design/cr-preflight/CR-NNNN.md` or its APPROVED/active state. DOCUMENTATION/TEST_ARTIFACT can also run with no `--cr`.

**Recommendation.** Require active CR + matching active/approved preflight for every review that can satisfy mandatory workflow closure. If standalone advisory review is useful, give it a distinct non-authorizing mode/verdict.

**Evidence anchor.** `WORKFLOW.md`; `review_gate.py::main`, `load_cr_scope`.

### ZG-025 — P0 — Non-CODE TOCTOU

**Finding.** CODE is revalidated immediately before PASS receipt creation; DOCUMENTATION and TEST_ARTIFACT have no equivalent final revalidation. A document or evidence file can change after packet construction while the returned result still says PASS.

**Recommendation.** Bind immutable copied bytes or Git objects and revalidate the exact document/evidence index immediately before emitting an authorizing/closure PASS.

**Evidence anchor.** `revalidate_before_receipt`; `main`/`write_telemetry`; DOCUMENTATION and TEST_ARTIFACT packet builders.

### ZG-026 — P0 — Normal-gate self-certification

**Finding.** The normal gate does not appear to reject a CODE change that modifies `review_gate.py`, its governing contract, or other gate-authority code. The existence of a bootstrap command does not itself prevent accidental self-certification.

**Recommendation.** Define a maintenance-protected path set and make normal CODE review refuse those changes with an explicit `BOOTSTRAP_REQUIRED` result.

**Evidence anchor.** `review_gate.py`; bootstrap architecture in `design/FRESH-PROJECT-EXTERNAL-REVIEW-GATE.md`.

### ZG-027 — P0 — Bootstrap independence

**Finding.** `legacy_bootstrap_gate.py` imports `CodeReviewerClient`, packet builders, validators and decision support directly from `review_gate.py`, contrary to the reusable standard's explicit independence requirement.

**Recommendation.** Implement a truly standalone bootstrap reviewer: independent packet construction, transport/request shape, schema validation and receipt synthesis. Shared constants may be duplicated/pinned rather than imported from the code under review.

**Evidence anchor.** `tools/reviewer/legacy_bootstrap_gate.py`; reusable standard bootstrap requirements.

### ZG-028 — P0 — Scoped bootstrap can authorize full change

**Finding.** Bootstrap `--path` and line slicing remove review records while preserving the full CODE snapshot identity. A subset review can therefore issue `bootstrap-pass.json` that the maintenance harness interprets as authorization for the whole diff.

**Recommendation.** Disallow scoped/sliced operation for authorizing bootstrap PASS. If diagnostic scoped review is retained, mark it non-authorizing with a different snapshot/receipt type.

**Evidence anchor.** `legacy_bootstrap_gate.py::scoped_bootstrap_packet`, receipt writer.

### ZG-029 — P0 — Bootstrap final revalidation

**Finding.** Bootstrap validates the code snapshot only when constructing the packet; it does not repeat HEAD/clean-tree/CR/preflight/scope checks immediately before writing `bootstrap-pass.json`.

**Recommendation.** Perform independent post-review revalidation before any maintenance receipt is written, and bind CR/preflight/scope identities into that receipt.

**Evidence anchor.** `legacy_bootstrap_gate.py::main`.

### ZG-030 — P0 — Bootstrap root of trust

**Finding.** Repairing the contaminated bootstrap creates a bootstrap-of-bootstrap problem: the replacement must not be solely certified by either the normal gate being changed or the new bootstrap itself.

**Recommendation.** Use a one-time explicit root-of-trust ceremony: frozen current bytes and authority, independent manual/external audit of the standalone replacement, immutable hash/commit record, authorized maintenance validation, then cut over. Record the procedure in the CR.

**Evidence anchor.** Reusable standard bootstrap model; current bootstrap dependency violation.

### ZG-031 — P1 — Bootstrap model reasoning profile

**Finding.** Bootstrap is a high-consequence semantic audit but is hard-coded non-thinking. Once independence and answer-budget safety are fixed, this is a relevant prompt for stronger reasoning.

**Recommendation.** Qualify and use Ultra high reasoning for substantive bootstrap review with a separate reasoning budget and final JSON reserve. Keep any pure schema repair non-thinking and non-authoritative.

**Evidence anchor.** `legacy_bootstrap_gate.py`; user requirement to enable thinking where applicable; NVIDIA Ultra reasoning controls.

### ZG-032 — P0 — Legacy CODE receipts

**Finding.** `invoke_remote_harness.py::validate_review_authority()` returns early for review protocol versions below 2. Old reduced-authority receipts can therefore remain potentially usable if other legacy fields happen to pass.

**Recommendation.** Set a minimum/current accepted protocol explicitly and reject legacy receipts for protected execution. Provide a one-time invalidation/migration rather than indefinite backwards authorization.

**Evidence anchor.** `invoke_remote_harness.py::validate_review_authority`.

### ZG-033 — P0 — Bootstrap maintenance receipt strength

**Finding.** Maintenance authorization checks fewer bindings than normal CODE authorization: it does not establish the same CR/preflight/scope/packet-profile integrity chain.

**Recommendation.** Define a bootstrap receipt schema with exact snapshot, CR/preflight, authority digest(s), bootstrap implementation/profile hash and packet hash; verify every field before maintenance execution.

**Evidence anchor.** `invoke_remote_harness.py::require_bootstrap_maintenance_pass`; bootstrap receipt writer.

### ZG-034 — P0 — Model-driven context data policy

**Finding.** `resolve_context_request()` PATH/SYMBOL/ARTIFACT_SLICE can retrieve bytes after discovery without consistently reapplying `enforce_external_review_data_policy()`. SYMBOL can search broadly through the reviewed tree.

**Recommendation.** Apply policy to every dynamically resolved path and every extracted context before transmission. Denied required evidence => INCONCLUSIVE, never silent omission.

**Evidence anchor.** `resolve_context_request`; `enforce_external_review_data_policy`.

### ZG-035 — P0 — Secret content inside allowed files

**Finding.** The external-review data policy is primarily path/name/suffix based. A credential accidentally committed inside an otherwise allowed `.c`, `.md`, log or JSON file can be transmitted.

**Recommendation.** Add deterministic high-confidence secret scanning/redaction/blocking for outbound model payload material, with an allowlist/override process for false positives. Never log matched secret values.

**Evidence anchor.** `enforce_external_review_data_policy`; all outbound packet/context paths.

### ZG-036 — P0 — TEST result-manifest status parse

**Finding.** `verify_platform_evidence.py` writes lane status under `result["summary"]["status"]`; `test_artifact_packet()` reads `payload.get("status")`. Valid retained manifests are therefore classified as non-passing anomalies.

**Recommendation.** Consume the canonical verifier schema (`summary.status`) rather than inventing a second interpretation. Add a fixture generated by the real verifier and feed it into TEST packet construction.

**Evidence anchor.** `verify_platform_evidence.py::inspect_lane`; `review_gate.py::test_artifact_packet`.

### ZG-037 — P0 — TEST anomalies are not fail-closed

**Finding.** `test_artifact_packet()` records malformed/non-passing result manifests as `anomalies`, but `insufficient_evidence` is set only for missing/extra lane directories. A complete directory set with bad manifests can continue to model review and potentially PASS.

**Recommendation.** Any deterministic completeness/integrity/status anomaly that invalidates mandatory evidence must produce INCONCLUSIVE before the model call. Semantic warning signals may proceed as indexed anomalies, but structural failures may not.

**Evidence anchor.** `test_artifact_packet`.

### ZG-038 — P0 — TEST lane completeness definition

**Finding.** Lane completeness is inferred from top-level directory names of any indexed file, not from exactly one valid `result-manifest.json` with a matching `lane_id`. A directory can satisfy presence without a valid lane manifest.

**Recommendation.** Derive lanes from validated manifests; require exactly one manifest for each expected lane, zero duplicates, zero unknown lane IDs, and exact lane-ID agreement with the authoritative matrix.

**Evidence anchor.** `test_artifact_packet`; publication gate's exact-20 intent.

### ZG-039 — P0 — Retry artifact directory identity

**Finding.** Hosted upload retries can produce artifact directories suffixed `-retry-2`/`-retry-3`. TEST currently derives lane identity from directory names, so a valid retried upload can appear as one missing lane plus one unexpected lane.

**Recommendation.** Use embedded validated `lane_id` as identity and treat artifact-directory names as transport metadata only. Detect multiple bundles for one lane deterministically.

**Evidence anchor.** `platform-smoke.yml` upload retry names; `test_artifact_packet` lane derivation.

### ZG-040 — P0 — TEST run/build/publication provenance

**Finding.** `run_id`, `build_id` and `publication_id` are caller strings included in the packet hash, but current lane evidence does not independently prove that those identifiers belong to the retained files.

**Recommendation.** Create/retain a publication-level provenance manifest from GitHub metadata binding workflow run ID, commit SHA/build identity, exact 20 jobs, artifact IDs/names/hashes and lane manifests. Verify caller arguments against it.

**Evidence anchor.** `test_artifact_packet`; hosted publication gate.

### ZG-041 — P0 — Expected lane set tied to current tree

**Finding.** `expected_platform_lanes()` reads the current working-tree `platform-smoke.yml`, not necessarily the workflow blob used by the tested run/commit.

**Recommendation.** Bind expected lanes to the tested commit/workflow blob SHA from the publication provenance. A later workflow edit must not reinterpret old evidence.

**Evidence anchor.** `expected_platform_lanes`; TEST snapshot provenance.

### ZG-042 — P0 — TEST evidence-root traversal/symlinks

**Finding.** The evidence root itself is constrained inside the repository, but recursive file reads can follow symlinked files to content outside the authorized evidence root/project boundary.

**Recommendation.** Use `lstat`, reject symlink traversal (or resolve and prove every target remains inside the canonical root), and apply outbound data policy to every indexed/retrieved artifact.

**Evidence anchor.** `test_artifact_packet` recursive indexing; `ARTIFACT_SLICE` resolution.

### ZG-043 — P1 — TEST index semantic classification

**Finding.** TEST index entries contain path/size/hash/line_count but no text/binary/image/extraction classification. `line_count` is derived using replacement decoding, then ARTIFACT_SLICE later strict-decodes the file.

**Recommendation.** Classify every artifact once at indexing time. Permit text slices only for immutable UTF-8 text or approved text extraction; represent binary/visual evidence explicitly and fail closed when required semantics are unavailable.

**Evidence anchor.** `test_artifact_packet`; `resolve_context_request` ARTIFACT_SLICE.

### ZG-044 — P0 — Mandatory exact evidence before TEST confirmation

**Finding.** Indexed TEST candidates can validate a location from metadata without being forced to retrieve the cited artifact bytes. Falsification can therefore judge a product/test allegation from the compact index/model-authored claim without exact decisive source evidence.

**Recommendation.** Before a TEST candidate can be confirmed, automatically retrieve a bounded hash-checked artifact slice (or approved extraction) covering its cited location. If semantics cannot be obtained, classify EVIDENCE_INSUFFICIENT/UNRESOLVED.

**Evidence anchor.** `candidate_location_valid`; `falsification_evidence`; `ARTIFACT_SLICE`.

### ZG-045 — P1 — TEST semantic anomaly surface

**Finding.** The compact TEST packet mainly contains lane/file counts, hashes, groups and deterministic anomalies. It does not surface bounded exact excerpts for high-signal raw textual failures/contradictions, so discovery may have too little semantic evidence to find issues without already knowing what to request.

**Recommendation.** Deterministically scan text for structured high-signal events (test failures, assertion records, nonzero exit records, explicit error fields, status contradictions) and include bounded exact excerpts with hashes. Treat keywords as leads, not defects.

**Evidence anchor.** `test_artifact_packet`; TEST discovery design.

### ZG-046 — P1 — TEST result grouping

**Finding.** `result_groups` hashes entire lane result manifests. Platform/lane-specific fields make semantically equivalent successful outcomes look unique, reducing the intended deduplication benefit.

**Recommendation.** Compute a deterministic semantic result signature from normalized test outcomes/coverage/status fields while preserving each lane's separate identity and full hash.

**Evidence anchor.** `test_artifact_packet` grouping.

### ZG-047 — P1 — Canonical evidence verifier drift

**Finding.** `verify_platform_evidence.py`, the shell publication gate and `test_artifact_packet()` each implement overlapping but different evidence validity rules.

**Recommendation.** Extract one reusable deterministic evidence-schema verifier/library used by lane creation, publication verification and TEST indexing. Keep shell only for orchestration/count assertions that call the canonical verifier.

**Evidence anchor.** `verify_platform_evidence.py`; `platform-smoke.yml`; `review_gate.py`.

### ZG-048 — P0 — Structured evidence hash binding

**Finding.** `result-manifest.json` embeds `summary`, `inventory` and Fuse data, but `--verify-tree` only re-hashes retained screenshots/traces. It does not verify that source `summary.json`, `inventory.json` and Fuse manifest files still match the embedded result.

**Recommendation.** Hash/bind every structured source file in the result manifest and revalidate those hashes at publication and TEST review time.

**Evidence anchor.** `verify_platform_evidence.py::inspect_lane`, `--verify-tree`.

### ZG-049 — P0 — Fuse manifest semantic verification

**Finding.** The lane verifier only checks that `fuse-complete-manifest.json` is a non-empty dict. The producer manifest contains pinned commit, selection, totals, pass/fail counts, silent skips, known unresolved and unexpected failures; those semantics are not validated by the evidence verifier.

**Recommendation.** Validate the exact Fuse schema and invariants, including pinned commit, expected selection/count, zero unexpected failures, silent-skip rule and internally consistent case totals. Bind the unresolved-baseline identity where applicable.

**Evidence anchor.** `run_fuse_ed_corpus.py`; `run_fuse_ed_platform.py`; `verify_platform_evidence.py`.

### ZG-050 — P1 — Evidence inspection terminology

**Finding.** `verify_platform_evidence.py` labels screenshots/traces as `inspected` when it has only enumerated and hashed them. This overstates semantic inspection.

**Recommendation.** Rename to `present_and_hash_verified` (or perform actual approved semantic inspection). Keep visual semantics explicitly unavailable to the text-only gate unless separately described/extracted.

**Evidence anchor.** `verify_platform_evidence.py` inspection status fields.

### ZG-051 — P1 — Sokol hosted evidence retention

**Finding.** The supported Sokol host smoke writes to sibling directories `<lane>-sokol`, while lane verification/upload targets `<lane>`. The Sokol smoke evidence is therefore not part of the retained bundle consumed by the publication/TEST evidence path.

**Recommendation.** Place Sokol evidence inside the canonical lane bundle or upload/bind it explicitly into that lane's manifest and publication provenance.

**Evidence anchor.** `.github/workflows/platform-smoke.yml`.

### ZG-052 — P0 — Hosted tests can precede CODE PASS

**Finding.** `platform-smoke.yml` triggers automatically on push to `main` and pull requests and does not verify the private CODE PASS receipt before running build/tests. This conflicts with the tracked rule that no CR code executes on an approved remote/hosted system before CODE PASS.

**Recommendation.** Choose and enforce one architecture: trigger protected hosted tests only from an authorization mechanism bound to the CODE PASS, or explicitly redefine which CI executions are non-protected. Do not rely on a private local receipt that GitHub cannot see without a secure publication mechanism.

**Evidence anchor.** `WORKFLOW.md` External Review Gate; `.github/workflows/platform-smoke.yml` triggers.

### ZG-053 — P1 — Hosted cancellation policy

**Finding.** `WORKFLOW.md` says never cancel/replace a live run, while `platform-smoke.yml` uses `concurrency.cancel-in-progress: true` and housekeeping may cancel older queued/in-progress runs for the same ref.

**Recommendation.** Resolve the policy explicitly. Given the project's stated terminal-state requirement, prefer preserving live acceptance runs; if housekeeping cancellation is retained, document exactly which runs are non-authoritative and cannot be reused.

**Evidence anchor.** `WORKFLOW.md`; `platform-smoke.yml`; `cleanup-hosted-runner-state.sh`.

### ZG-054 — P1 — 20-lane acceptance contract contradiction

**Finding.** The workflow publication gate requires exactly 20 successful jobs, while `WORKFLOW.md` also says publication requires only one successful Intel macOS lane plus one ARM lane and allows local substitution at CR closure. These are different acceptance semantics.

**Recommendation.** Align documentation to the actual mandatory exact-20 publication gate unless the operator deliberately changes policy. Do not weaken the 20-lane matrix as part of gate optimization.

**Evidence anchor.** `WORKFLOW.md`; `.github/workflows/platform-smoke.yml` publication-gate.

### ZG-055 — P1 — Thinking profile contract drift

**Finding.** `design/review-gate.md` says falsification/adjudication use thinking, but current `perform_review()` passes `thinking="disabled"` for falsification and adjudication. Discovery is also disabled.

**Recommendation.** After P0 trust fixes, enable reasoning by phase: medium for substantive discovery, high for hostile falsification and adjudication. Keep health checks and pure formatting repair non-thinking. Update code, contract and tests together.

**Evidence anchor.** `perform_review`; `design/review-gate.md`; NVIDIA Ultra hosted reasoning controls.

### ZG-056 — P1 — Invalid reasoning-effort abstraction

**Finding.** `CodeReviewerClient` accepts only internal efforts `high` and `max`; NVIDIA's hosted Ultra API exposes `none`, `medium`, `high` and does not define `max`. The current effort string is not sent to the API at all.

**Recommendation.** Model the provider contract directly: top-level `reasoning_effort` with `none|medium|high` for the hosted endpoint, plus separately configured reasoning budget where desired. Remove `max`.

**Evidence anchor.** `CodeReviewerClient.request`; NVIDIA model-specific hosted API.

### ZG-057 — P1 — Reasoning budget consumes answer budget

**Finding.** When internal `reasoning_effort` is non-null, current code sets `reasoning_budget = max_tokens`. With thinking enabled, this can consume the complete generation allowance before required JSON is emitted.

**Recommendation.** Set `max_tokens` to reasoning allowance + explicit final-answer reserve, with `reasoning_budget < max_tokens`. Use phase-specific budgets and test truncation at the boundary.

**Evidence anchor.** `CodeReviewerClient.request`; NVIDIA Ultra documentation explicitly demonstrates `max_tokens > reasoning_budget`.

### ZG-058 — P1 — Discovery reasoning choice

**Finding.** CODE, DOCUMENTATION and TEST discovery are semantic correctness tasks. Given the user's preference to enable thinking where relevant, disabling reasoning entirely sacrifices useful analysis quality after packets have already been optimized.

**Recommendation.** Qualify Ultra `medium` reasoning as the clean-path discovery default. Keep one discovery call for clean reviews; do not reintroduce multi-pass LLM summaries.

**Evidence anchor.** Discovery calls; NVIDIA `reasoning_effort=medium` is the efficient reasoning mode.

### ZG-059 — P1 — High reasoning for falsification/adjudication

**Finding.** Hostile falsification and evidence-backed adjudication are the highest-value reasoning stages, yet both currently run non-thinking.

**Recommendation.** Use `reasoning_effort=high` with bounded reasoning budget and protected final-answer reserve. Adjudication remains exceptional and candidate-scoped.

**Evidence anchor.** `perform_review`; NVIDIA `reasoning_effort=high`.

### ZG-060 — P1 — HTTP 202 pending

**Finding.** NVIDIA's model-specific API documents HTTP 202 as a pending result that should be polled using `requestId`. Current client expects an immediate `choices` array, so a 202 payload is treated as malformed output and can trigger a fresh generation request.

**Recommendation.** Implement the documented polling path within the same review deadline and count it as one logical inference. Do not POST a duplicate inference merely because the original is pending.

**Evidence anchor.** `CodeReviewerClient.request`; official hosted endpoint response contract.

### ZG-061 — P1 — Transport vs schema retry multiplication

**Finding.** `CodeReviewerClient.request` retries malformed/shape-invalid provider output through the transport retry loop, while `request_validated` performs up to two additional semantic schema repairs. One logical phase can multiply into many full inference calls.

**Recommendation.** Separate transport retries from application-schema repair. Transport retries only for documented transient transport/status failures; one bounded schema-repair policy for successfully completed inference. Record logical inference ID versus HTTP attempts.

**Evidence anchor.** `CodeReviewerClient.request`; `request_validated`.

### ZG-062 — P1 — Retry-After and deadline-aware backoff

**Finding.** Backoff uses fixed sleeps and does not honor `Retry-After`; sleep itself is not clamped to remaining overall deadline.

**Recommendation.** Honor provider Retry-After when present, cap all waits by remaining deadline, and fail before sleeping past authorization expiry.

**Evidence anchor.** `RETRY_DELAYS`; client retry loop.

### ZG-063 — P2 — HTTP 404 retry qualification

**Finding.** The model-specific hosted endpoint documentation does not list 404 as a normal pending/transient response, while current code always retries 404.

**Recommendation.** Retain 404 retry only if there is measured NVIDIA hosted behavior requiring it and document that evidence; otherwise treat it as configuration/not-found rather than spending seven attempts.

**Evidence anchor.** `RETRYABLE_HTTP_STATUS`; official model endpoint response list.

### ZG-064 — P2 — Sampling profile

**Finding.** Current client recently added `temperature: 0.0`. NVIDIA Ultra examples/defaults use the model's normal sampling profile; a zero-temperature override was not part of the gate's earlier validated contract.

**Recommendation.** Qualification-test reasoning quality and JSON reliability with provider-recommended/default sampling. Unless evidence shows a benefit, avoid bespoke sampling controls; never change temperature and top_p together.

**Evidence anchor.** `CodeReviewerClient.request`; NVIDIA Ultra model page/API guidance.

### ZG-065 — P1 — Structured output capability

**Finding.** `response_format={"type":"json_object"}` guarantees JSON syntax, not the gate's full application schema. NVIDIA supports stronger structured generation in some NIM configurations, but reasoning-budget compatibility/backend support varies.

**Recommendation.** Capability-test the exact hosted Ultra endpoint. If schema-constrained output is supported together with the chosen reasoning mode, adopt it; otherwise retain deterministic validators/repairs. Never assume self-hosted NIM features exist on hosted Build API.

**Evidence anchor.** Client response format; NVIDIA structured-generation/thinking-budget documentation.

### ZG-066 — P2 — Health-check budget

**Finding.** Health check asks for one tiny JSON object but uses the normal 8192-token discovery allowance and accepts a `--requirements` CLI argument it does not use.

**Recommendation.** Use a small non-thinking output budget (for example 64-256 tokens), remove or actually validate the unused argument, and keep health check outside review authority.

**Evidence anchor.** `review_gate.py::health-check`.

### ZG-067 — P2 — Telemetry logical-vs-physical calls

**Finding.** `telemetry.calls` counts every HTTP attempt while schema repair also increments `telemetry.retries`. The metrics do not clearly separate logical review inferences, transport attempts, provider polling and schema repair calls.

**Recommendation.** Record logical inference ID/phase, POST attempts, polling requests, schema-repair generation count, retry reason and reasoning-token usage separately.

**Evidence anchor.** `Telemetry`; `CodeReviewerClient.request`; `request_validated`.

### ZG-068 — P1 — Review profile binding

**Finding.** PASS receipts bind protocol/snapshot/authority but not an immutable gate implementation/profile identity (model, endpoint profile, reasoning settings, schema version, key policy/budgets). A materially changed reviewer profile can coexist with old receipts.

**Recommendation.** Define a canonical review-profile manifest/hash and bind it into telemetry/receipts. Protected execution should require an accepted profile generation for the current gate protocol.

**Evidence anchor.** Receipt writer; remote verifier; model configuration constants.

### ZG-069 — P2 — Context budget accounting

**Finding.** `MAX_CONTEXT_TOKENS=1_000_000` is declarative while actual admission uses byte ceilings. Byte-only limits are safe but neither accurately use nor measure the provider context window.

**Recommendation.** Keep conservative byte hard limits, but add tokenizer/observed prompt-token telemetry for tuning. Do not chase the 1M maximum; minimum-sufficient packets are preferable.

**Evidence anchor.** Budget constants; telemetry.

### ZG-070 — P1 — TEST requirement transmission

**Finding.** Normal CODE/DOCUMENTATION now use minimal linked requirement excerpts, but TEST_ARTIFACT still takes full requirement files through `requirement_records`, repeating potentially large authority content on discovery/falsification.

**Recommendation.** Give TEST a compact acceptance/requirement index or linked requirement excerpts while preserving full-source hashes and bounded exact requirement retrieval on demand.

**Evidence anchor.** `main`; TEST packet path; `stable_prefix`.

### ZG-071 — P1 — Prior/dispute evidence provenance

**Finding.** Prior finding records require source/location/claim strings but do not bind evidence bytes/hashes/snapshot identity. Dispute resolution also routes evidence through generic PATH behavior that is poorly suited to indexed TEST artifacts.

**Recommendation.** Version prior-evidence records with source hash/snapshot/evidence type and resolve them through the same immutable CODE/DOC/TEST source adapter used by the current candidate.

**Evidence anchor.** `validate_prior`; dispute/adjudication path.

### ZG-072 — P1 — Empty-record location validation

**Finding.** `candidate_location_valid()` uses `max(1, line_count)`, making line 1 appear valid for an empty indexed/record source.

**Recommendation.** Zero-line evidence must have no valid source line. Reject `line_count == 0` locations and add empty-file fixtures.

**Evidence anchor.** `candidate_location_valid`.

### ZG-073 — P2 — Large artifact memory behavior

**Finding.** TEST indexing and ARTIFACT_SLICE currently read complete artifact bytes into memory to hash/decode even when only metadata or a small slice is needed.

**Recommendation.** Stream hashes and line indexes for large files; retrieve bounded text ranges without loading multi-gigabyte logs wholesale. Preserve exact SHA verification.

**Evidence anchor.** `test_artifact_packet`; ARTIFACT_SLICE.

### ZG-074 — P2 — Compact unresolved output

**Finding.** Material unresolved results can include resolved-context objects containing substantial source text. This can feed large evidence back into the developer context, contrary to the low-context gate objective.

**Recommendation.** Developer-facing result should contain compact provenance pointers, hashes, ranges and concise reasons. Keep exact context in private reviewer evidence/telemetry files, not stdout.

**Evidence anchor.** `perform_review` unresolved result construction.

### ZG-075 — P2 — Deterministic source line views

**Finding.** Linked related excerpts are line-numbered, but other model-facing text paths are not uniformly represented with deterministic original line numbers, making exact location generation and validation less reliable.

**Recommendation.** Use a canonical numbered-view adapter for all source/document/log excerpts while hashing raw bytes separately.

**Evidence anchor.** `line_excerpt`; file/context/artifact adapters.

### ZG-076 — P2 — Static contract/profile drift detection

**Finding.** Repository static validation does not appear to assert critical model-profile and contract invariants such as allowed reasoning efforts, reasoning-budget/final-reserve relationship, bootstrap independence, linked snapshot compatibility, and exact TEST schema field paths.

**Recommendation.** Add AST/text-contract checks for high-value invariants that can be proven statically. Keep behavioral tests for semantics.

**Evidence anchor.** `tools/validate_project_gates.py`; reviewer contract.

### ZG-077 — P2 — Regression suite gaps

**Finding.** Current tests explicitly encode obsolete/unsafe behaviors (for example `reasoning_effort="max"`, reasoning budget equal to `max_tokens`, malformed candidates being discarded) and do not exercise linked CODE review end-to-end into remote receipt authorization.

**Recommendation.** Replace those expectations with regression tests for every P0/P1 ledger item. Especially add linked packet candidate->falsifier->receipt->remote authorization, TEST canonical manifests, 202 polling and thinking-budget reserve fixtures.

**Evidence anchor.** `tests/test_review_gate.py`; `tests/test_remote_harness_gate.py`.

### ZG-078 — P2 — Change isolation

**Finding.** The gate, bootstrap, remote authorization and hosted evidence paths are all safety-critical and harness-lock protected. Fixing all findings in one large edit would make independent verification harder.

**Recommendation.** Implement in dependency-ordered CRs: (1) linked-packet/receipt false-PASS breakages; (2) TEST deterministic evidence; (3) bootstrap/root-of-trust; (4) reasoning/API profile; (5) optimization/telemetry; (6) workflow-contract cleanup. Re-run full gate precision fixtures after each.

**Evidence anchor.** `tools/harness/harness-lock.json`; project CR/preflight workflow.

### ZG-079 — P1 — Discovery envelope normalization can invent semantic completion

**Finding.** `normalize_discovery_response()` fills in the expected pass name when the model omitted it and accepts several alternative completion indicators before `discovery_schema_valid()` runs. Provider-shape aliasing is useful, but synthesizing semantic phase/completion acknowledgement weakens the fail-closed schema boundary.

**Recommendation.** Normalize only documented syntactic aliases. Do not invent `pass` or `review_complete=true`; those must be explicitly present in the model result (or recovered by a bounded schema-repair call). Add fixtures proving a clean-looking response that omits completion/phase remains schema-invalid.

**Evidence anchor.** `review_gate.py::normalize_discovery_response`, `request_validated`, `discovery_schema_valid`.

### ZG-080 — P1 — Linked discovery packet transmits semantic content multiple times

**Finding.** A linked packet stores complete requirement/related/prior/diff excerpts inside each `packet.manifest` entry and serializes the same entry again as `linked/<id>.json`. `stable_prefix()` separately transmits the requirement excerpt again. `build_review_units()` then sends the semantic manifest plus the linked record, causing substantial duplicate prompt bytes and making the “manifest” itself unshardably semantic.

**Recommendation.** Make the packet manifest metadata-only (IDs, ranges, hashes, classifications and bindings). Transmit each semantic excerpt exactly once in source/evidence records; keep authoritative requirement text in one stable location. Measure before/after clean CODE and DOCUMENTATION prompt bytes.

**Evidence anchor.** `linked_packet`, `stable_prefix`, `build_review_units`.

### ZG-081 — P2 — Falsification retransmits unrelated linked evidence

**Finding.** `falsification_evidence()` includes the complete `packet.manifest` for every candidate batch. Because the linked manifest currently contains semantic excerpts/diffs, each falsification batch retransmits all mapped links, including links unrelated to the candidate being falsified.

**Recommendation.** After making the manifest metadata-only, send only candidate-relevant linked records plus a compact complete-manifest identity. Resolve additional exact context on demand. Candidate batching should scale with candidate evidence, not total mapped change size.

**Evidence anchor.** `falsification_evidence`, `candidate_batches`, linked packet manifest structure.


### ZG-082 — P0 — CODE review base is not bound to the CR baseline

**Finding.** `validate_code_snapshot()` proves only that the caller-supplied base is an ancestor of current HEAD. The active CR/preflight does not supply and enforce a canonical review baseline. A caller can choose a too-recent base and exclude earlier changes belonging to the same CR from the change universe.

**Recommendation.** Record the CR review baseline (or an explicitly authorized replacement) in tracked CR/preflight state and require `--base` to equal it. Any baseline change must be explicit, justified and itself reviewable.

**Evidence anchor.** `validate_code_snapshot`; `load_cr_scope`; reusable gate snapshot policy.

### ZG-083 — P1 — Mandatory DOCUMENTATION review is not tied to the reviewed CODE commit

**Finding.** DOCUMENTATION linked packets are built from current filesystem bytes and do not carry the CODE-reviewed/published commit identity. Even with per-file hashes, the workflow cannot prove that factual documentation was reviewed against the same implementation snapshot that later executes.

**Recommendation.** For tracked documentation and implementation context, bind DOCUMENTATION review to an explicit Git commit—normally the current CODE-reviewed head—and read tracked bytes from that object. Auxiliary untracked/private documentation must be separately hash-bound. Revalidate before PASS.

**Evidence anchor.** `linked_packet` non-CODE branch; `WORKFLOW.md` CODE→DOCUMENTATION→publish ordering.

### ZG-084 — P1 — Gate/harness-lock authorization is not mechanically tied to gate surgery

**Finding.** `WORKFLOW.md` says every listed harness or its governing gate requires explicit operator authorization before modification, but the static gate does not establish a machine-verifiable relationship between a `review_gate.py`/bootstrap change and the active CR's recorded operator authorization.

**Recommendation.** Add a narrow governance check for protected gate/harness paths: when those paths change, require an active maintenance CR/preflight with an explicit operator-authorization marker and bootstrap-required disposition. Do not infer authorization from an old `last_authorized_change`.

**Evidence anchor.** `WORKFLOW.md` Harness Lock; `tools/harness/harness-lock.json`; `tools/validate_project_gates.py`.


### ZG-085 — P1 — Oversized linked evidence is still arbitrary character-sharded

**Finding.** `shard_records()` and truncation recovery can split a linked semantic JSON record by arbitrary character count. That can separate a requirement from its related control logic or cut a source construct mid-unit—the exact failure the minimum-sufficient review-map design was meant to avoid.

**Recommendation.** A linked map entry that cannot fit its bounded semantic unit should be rejected as too broad or split deterministically on source-line/symbol/section boundaries with explicit overlap and original range metadata. Never use arbitrary character sharding as semantic review authority.

**Evidence anchor.** `shard_records`, `split_review_unit`, linked record representation.

### ZG-086 — P1 — Multi-unit linked CODE loses cross-unit integration review

**Finding.** `perform_review()` marks cross-unit integration required when CODE has multiple discovery units, but `build_integration_unit()` only collects records whose paths begin `head/` or `base-deleted/`. Mandatory linked CODE records are named `linked/<id>.json`, so a split linked review can produce no integration unit at all.

**Recommendation.** Build integration evidence from linked source bindings/complete change index, not legacy record-name prefixes. If cross-unit integration cannot be represented within budget, return INCONCLUSIVE rather than silently skipping it.

**Evidence anchor.** `perform_review`, `build_integration_unit`, `linked_packet`.

### ZG-087 — P0 — Linked DOCUMENTATION location semantics can discard real findings

**Finding.** A linked DOCUMENTATION packet stores content under synthetic `linked/<id>.json` records rather than the actual document path. `candidate_location_valid()` validates packet record paths. A model that naturally cites the real document path/line can therefore be rejected; a model that cites `linked/<id>.json:1` may pass validation but loses the exact original document location semantics.

**Recommendation.** Define one canonical candidate location contract based on original source path and original line/range, backed by the linked manifest. Validate that source location directly and carry the synthetic record ID only as transport metadata.

**Evidence anchor.** `linked_packet`, `candidate_location_valid`, DOCUMENTATION candidate pipeline.


### ZG-088 — P1 — Deterministic candidate rejection can erase a serious allegation

**Finding.** `deterministic_filter()` uses the same rejection mechanism for harmless duplicates/out-of-scope candidates and for protocol/provenance failures such as malformed candidate fields, bad quotes or invalid locations. If every attempted serious allegation fails a mechanical citation detail, the gate can end with zero candidates and PASS even though discovery did not actually establish a clean review.

**Recommendation.** Classify deterministic dispositions. Safe duplicate/out-of-scope eliminations may be dropped; candidate protocol/provenance failures should receive one bounded repair/resolution attempt and then make the review INCONCLUSIVE if the allegation cannot be evaluated. Apply the rule to falsifier `new_candidates` too.

**Evidence anchor.** `deterministic_filter`; discovery/new-candidate flow.

### ZG-089 — P0 — TEST model cannot see the evidence paths needed for on-demand retrieval

**Finding.** `test_artifact_packet()` builds a complete local `files` list in `packet.evidence_index`, but the transmitted `test-evidence-index.json` contains only aggregate counts, hashes, lane summaries, anomalies and result-group hashes. The model is therefore not given the normal artifact path inventory needed to formulate an exact `ARTIFACT_SLICE` request.

**Recommendation.** Transmit a compact deterministic artifact index containing at least path, classification, size, line count, SHA-256 and lane association for every retained file (or an equivalent searchable deterministic index exposed through a pre-candidate query mechanism). Keep raw bytes local.

**Evidence anchor.** `test_artifact_packet` local `files`/`evidence_index` versus model-facing `context`.

### ZG-090 — P0 — TEST second opinion lacks representative structured test outcomes

**Finding.** TEST packet construction parses each `result-manifest.json` mainly to derive a top-level status and a hash group; it does not transmit the lane summary, inventory, Fuse pass/fail/skip semantics or a representative structured result for each equivalence group. A reviewer cannot meaningfully detect masked failures, cross-lane disagreement or proof insufficiency from counts/hashes alone.

**Recommendation.** After canonical deterministic validation, transmit the complete compact structured acceptance outcome for every lane or one representative per proven-equivalent outcome group plus lane membership and all differences. Include explicit summary status, tools/skips, platform identity, Fuse totals/unresolved/unexpected failures, visual/trace availability and other mandatory acceptance fields.

**Evidence anchor.** `test_artifact_packet`; `verify_platform_evidence.py` result schema; TEST discovery lenses.


### ZG-091 — P1 — Schema repair is a fresh semantic review, not a narrow repair

**Finding.** `request_validated()` responds to an application-schema failure by calling the model again on the full original semantic prompt plus a generic “return fresh JSON” instruction. It does not provide field-specific validation errors or constrain the second call to preserve the prior semantic result. A repair can therefore add/drop/change findings and consume another full review call.

**Recommendation.** Separate syntax/shape repair from semantic review. For a valid parsed result with repairable shape errors, supply the prior result plus exact validator errors to a non-authoritative formatter and then revalidate. Missing semantic evidence/fields that require new reasoning should trigger one explicit same-phase semantic retry or INCONCLUSIVE, not masquerade as formatting repair.

**Evidence anchor.** `request_validated`; client JSON parsing/retry loop.

### ZG-092 — P1 — Mandatory linked DOCUMENTATION bypasses approved extraction support

**Finding.** The normal DOCUMENTATION path now requires `--review-map` and uses `linked_packet()`, which directly UTF-8 decodes requirement/related files. The existing `file_packet()`/`--extraction-manifest` machinery for approved deterministic binary/visual representations is not used by this mandatory path.

**Recommendation.** Integrate approved extraction identities into linked document records, or explicitly restrict mandatory DOCUMENTATION to text and provide a separate evidence-bound extracted-document adapter. An acceptance-relevant non-text document must fail closed rather than silently becoming unsupported.

**Evidence anchor.** `main` DOCUMENTATION branch; `linked_packet`; `file_packet`; `load_extraction_manifest`.


## Recommended implementation order

**Wave 1 — eliminate false-PASS and broken-authorization paths.**  
Fix every P0 entry first, with special emphasis on linked-packet location/coverage/receipt integrity, CR/preflight/baseline authority, candidate/decision proof algebra, lock correctness, bootstrap trust, TEST deterministic completeness/provenance, outbound data boundaries, and protected hosted execution ordering. Do not enable stronger model reasoning while the harness can still discard or fail to supply decisive evidence.

**Wave 2 — canonicalize semantic evidence.**  
Complete the P1 evidence-path work: original source-location semantics, deletion/rename context, TEST file index and representative structured outcomes, canonical evidence verifier/Fuse semantics, candidate-specific falsification context, documentation commit/extraction binding, semantic sharding/integration, prior/dispute provenance, and map semantic-sufficiency rules.

**Wave 3 — enable the corrected NVIDIA reasoning/API profile.**  
After Waves 1–2 are proven, implement and qualify:
- HEALTH / pure formatting: reasoning `none`;
- CODE discovery: `medium`;
- DOCUMENTATION discovery: `medium`;
- TEST_ARTIFACT discovery: `medium`;
- cross-file/integration discovery when required: `high`;
- hostile falsification: `high`;
- evidence-backed adjudication: `high`;
- standalone bootstrap maintenance review: `high`;
- compact formatting fallback: non-thinking and non-authoritative.

Use only provider-supported `none|medium|high`, keep `reasoning_budget < max_tokens`, implement HTTP-202 polling, and separate transport retries from schema/semantic retries.

**Wave 4 — optimize and harden observability/governance.**  
Apply the remaining P2 recommendations plus any P1 efficiency items not prerequisites above: de-duplicate linked semantic transmission, candidate-scope falsification evidence, stream large artifact hashing, compact developer-facing unresolved output, improve telemetry/accounting, qualify sampling/structured output, bind the review profile, strengthen static drift checks, and keep gate surgery in small independently verifiable CRs.

**Completion rule.**  
No wave may close merely because its named code paths were edited. Close it only after its relevant acceptance tests below pass and a fresh zero-gap review finds no new bypass, stale contract, or unnecessary model call.

## Acceptance tests required before declaring remediation complete

At minimum, the remediation should prove:

1. a valid HIGH candidate from a linked CODE source line survives deterministic validation and reaches falsification;
2. a linked CODE PASS receipt is accepted by the remote authorization harness only for the exact reviewed commit and packet;
3. an omitted changed path or acceptance requirement makes the map incomplete and the gate non-PASS;
4. two requirement excerpts from the same source remain distinct and do not break remote receipt validation;
5. `--scope-file + --review-map` survives end-to-end receipt validation;
6. deletion, rename/copy, text, binary, symlink and gitlink changes have explicit coverage semantics;
7. DOCUMENTATION `--path` is actually the reviewed document-set authority;
8. nonempty discovery uncertainty/evidence request cannot fall through to PASS;
9. malformed candidate output receives repair/INCONCLUSIVE, never silent deletion;
10. decision/evidence-state algebra is enforced in Python;
11. falsifier proof must resolve to exact immutable evidence;
12. compact fallback cannot independently confirm/reject a candidate;
13. concurrent reviews cannot both acquire authority and a healthy 60-minute review never ages stale at 15 minutes;
14. every mandatory review requires the same active CR/preflight identity;
15. non-CODE evidence mutation before completion invalidates PASS;
16. normal gate refuses to self-certify protected gate changes;
17. bootstrap contains no imports from the normal gate and scoped diagnostics cannot produce an authorizing receipt;
18. current protocol rejects legacy receipts;
19. a real `verify_platform_evidence.py` manifest is parsed correctly by TEST review;
20. exactly one validated manifest per expected lane is required;
21. retry-named artifact bundles resolve through embedded lane IDs without false missing/extra classification;
22. run/commit/build/publication provenance is cryptographically bound;
23. tested workflow/lane authority comes from the tested commit;
24. evidence-root symlink escape is rejected;
25. a TEST candidate cannot be confirmed without exact hash-checked artifact semantics;
26. mutated summary/inventory/Fuse files fail publication verification;
27. Fuse semantic invariants are checked, not merely nonempty JSON;
28. Sokol evidence is in the retained canonical bundle;
29. hosted protected execution ordering is reconciled with CODE PASS policy;
30. one exact-20 hosted acceptance rule exists in code and documentation;
31. provider payload uses only supported Ultra reasoning values;
32. medium/high reasoning phases have `reasoning_budget < max_tokens` with a tested final JSON reserve;
33. HTTP 202 polls instead of issuing a duplicate generation;
34. transport retries, provider polling and schema repairs have distinct bounded counters;
35. health check uses a tiny non-thinking budget;
36. current review profile is bound into PASS authority;
37. TEST full local evidence bytes may grow without proportional semantic API calls on a clean run;
38. a clean 20-lane TEST review reaches one targeted discovery call unless actual anomalies/context needs justify more;
39. discovery output that omits explicit phase/completion cannot be normalized into a complete pass;
40. linked discovery transmits each semantic excerpt only once, and falsification sends only candidate-relevant evidence;
41. CODE rejects a caller-selected base that differs from the CR's authoritative baseline;
42. DOCUMENTATION PASS is bound to the exact CODE implementation commit it describes;
43. protected gate/harness edits require mechanically verifiable operator-authorized maintenance state;
44. oversized linked evidence never uses arbitrary character sharding as semantic authority;
45. split linked CODE performs a real cross-unit integration review or fails closed;
46. DOCUMENTATION candidates cite and validate original document path/range rather than synthetic record line 1;
47. serious candidate protocol/provenance failures cannot disappear into PASS;
48. TEST discovery receives a compact path/classification/hash index sufficient to request exact evidence;
49. TEST discovery receives representative structured lane/Fuse outcomes, not merely hashes;
50. schema repair cannot silently become a second unconstrained semantic reviewer;
51. linked DOCUMENTATION preserves approved extraction/provenance semantics for non-text inputs.

## Sanity-audit protocol

A “zero-gap” pass means all of the following were checked against the pinned baseline:

- forward pass: every material behavior in model transport, schema validation, packet construction, context retrieval, proof synthesis, receipts, locks, bootstrap, TEST evidence, remote authorization and hosted publication has a recommendation or an explicit no-change disposition;
- reverse pass: every recommendation corresponds to observed code/contract/provider behavior and does not rely on stale pre-`6ba164cc` state;
- cross-contract pass: `design/review-gate.md`, reusable gate standard, `WORKFLOW.md`, normal gate, bootstrap, remote harness and 20-lane workflow do not expose an unlogged contradiction;
- optimization pass: no recommendation saves tokens by silently dropping evidence or adding an LLM-summary authority tier;
- model pass: reasoning recommendations use only current officially documented Ultra controls and preserve a final-answer reserve;
- regression pass: every P0/P1 recommendation has an explicit testable acceptance condition.

## Zero-gap certification log

**Audit A — forward source/contract → ledger:** ZERO GAPS on the frozen ledger candidate after incorporating the current-main linked-packet regressions, TEST schema issues, bootstrap trust chain, hosted ordering/cancellation contradictions, and provider reasoning/pending-response contract.

**Audit B — reverse ledger → source/contract/provider:** ZERO GAPS on the identical frozen ledger bytes. No entry depended on the retired Windows-11/Big-Sur local lanes; the lab-reduction commit is orthogonal to these recommendations except that it changed the pinned `main` commit.

Certification is valid only for repository commit `6ba164cc125b7f2a78c58f7a3047090d530e7fa5`. A later change to any relevant component requires delta revalidation before calling this ledger current.

