#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXCLUDE={'PACKAGE-MANIFEST.json','CERTIFICATION.json'}
EXCLUDE_PREFIX=('audit/results/','__pycache__/')
def sha(b):return hashlib.sha256(b).hexdigest()
files=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(ROOT).as_posix()
 if rel in EXCLUDE or any(rel.startswith(x) for x in EXCLUDE_PREFIX) or '/__pycache__/' in '/'+rel:continue
 if rel.endswith('.pyc') or rel.endswith('.zip'):continue
 data=p.read_bytes(); files.append({'path':rel,'sha256':sha(data),'bytes':len(data)})
tree=sha(json.dumps(files,ensure_ascii=True,separators=(',',':'),sort_keys=True).encode())
manifest={'schema_version':1,'baseline_commit':'6ba164cc125b7f2a78c58f7a3047090d530e7fa5','ledger_sha256':'5abd88f6bc8abc22bc13968ec1ea762697d7db34c11ab94d780beadd0d1079c9','files':files,'tree_sha256':tree}
(ROOT/'PACKAGE-MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(tree)
