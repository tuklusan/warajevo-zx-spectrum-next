#!/usr/bin/env python3
from __future__ import annotations
import argparse,ast,hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
LEDGER_SHA='5abd88f6bc8abc22bc13968ec1ea762697d7db34c11ab94d780beadd0d1079c9'
BASE='6ba164cc125b7f2a78c58f7a3047090d530e7fa5'
LANES=['linux-x64','linux-x64-latest','linux-x64-24','linux-x64-26','linux-arm64-22','linux-arm64','linux-arm64-26','windows-latest','windows-server-2022','windows-server-2025','windows-server-2025-vs2026','windows-arm-11','windows-arm-11-vs2026','macos-arm64-latest','macos-arm64','macos-arm64-14','macos-intel-x64','macos-intel-26','macos-arm64-26','macos-xcode-27']
LABELS=['ubuntu-22.04','ubuntu-latest','ubuntu-24.04','ubuntu-26.04','ubuntu-22.04-arm','ubuntu-24.04-arm','ubuntu-26.04-arm','windows-latest','windows-2022','windows-2025','windows-2025-vs2026','windows-11-arm','windows-11-vs2026-arm','macos-latest','macos-15','macos-14','macos-15-intel','macos-26-intel','macos-26','xcode-27']
def sha(b):return hashlib.sha256(b).hexdigest()
def fail(errors,msg):errors.append(msg)
def read(rel):return (ROOT/rel).read_text(encoding='utf-8')
def manifest_check(errors):
 p=ROOT/'PACKAGE-MANIFEST.json'
 if not p.is_file():return fail(errors,'PACKAGE-MANIFEST.json missing')
 m=json.loads(p.read_text());
 if m.get('baseline_commit')!=BASE or m.get('ledger_sha256')!=LEDGER_SHA:fail(errors,'manifest authority mismatch')
 canon=[]
 for rec in m.get('files',[]):
  f=ROOT/rec['path']
  if not f.is_file():fail(errors,'manifest file missing '+rec['path']);continue
  b=f.read_bytes()
  if sha(b)!=rec.get('sha256') or len(b)!=rec.get('bytes'):fail(errors,'manifest file changed '+rec['path'])
  canon.append({'path':rec['path'],'sha256':sha(b),'bytes':len(b)})
 tree=sha(json.dumps(canon,ensure_ascii=True,separators=(',',':'),sort_keys=True).encode())
 if tree!=m.get('tree_sha256'):fail(errors,'manifest tree hash mismatch')
 return m

def static_checks(errors):
 ledger=(ROOT/'ledger/WZXN-GATE-RECOMMENDATION-LEDGER-CERTIFIED.md').read_bytes()
 if sha(ledger)!=LEDGER_SHA:fail(errors,'ledger hash mismatch')
 ids=re.findall(rb'^### (ZG-\d{3})',ledger,re.M)
 if [x.decode() for x in ids]!=[f'ZG-{i:03d}' for i in range(1,93)]:fail(errors,'ledger is not exactly ZG-001..ZG-092')
 matrix=read('REMEDIATION-MATRIX.md')
 mids=re.findall(r'^\| (ZG-\d{3}) \|',matrix,re.M)
 if mids!=[f'ZG-{i:03d}' for i in range(1,93)]:fail(errors,'remediation matrix is not exactly ZG-001..ZG-092')
 if matrix.count('**ADDRESSED**')!=92:fail(errors,'not all ledger items marked ADDRESSED')
 gate=read('payload/tools/reviewer/review_gate.py'); boot=read('payload/tools/reviewer/legacy_bootstrap_gate.py'); auth=read('payload/tools/harness/review_authority_v4.py')
 profile=json.loads(read('payload/tools/reviewer/review-profile-v4.json'))
 if profile.get('protocol')!=4:fail(errors,'profile protocol is not v4')
 for name,v in profile.get('phase_profile',{}).items():
  if v.get('reasoning_effort') not in {'none','medium','high'}:fail(errors,'unsupported effort '+name)
  if v.get('reasoning_effort')!='none' and not int(v.get('reasoning_budget',0))<int(v.get('max_tokens',0)):fail(errors,'no answer reserve '+name)
 if profile['phase_profile']['CODE-DISCOVERY']['reasoning_effort']!='medium' or profile['phase_profile']['FALSIFICATION']['reasoning_effort']!='high' or profile['phase_profile']['ADJUDICATION']['reasoning_effort']!='high':fail(errors,'reasoning phase policy drift')
 if 'reasoning_effort="max"' in gate or '"max"}' in gate:fail(errors,'legacy max reasoning alias remains')
 if '"temperature"' in gate:fail(errors,'bespoke temperature override remains')
 for token in ('STATUS_URL','requestId','reasoning_budget','force_nonempty_content','BOOTSTRAP_REQUIRED','global-review.lock','candidate_protocol_gaps','proof_refs','Review-Base','review_base'):
  if token not in gate:fail(errors,'normal gate missing '+token)
 tree=ast.parse(boot); imports=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):imports += [a.name for a in n.names]
  elif isinstance(n,ast.ImportFrom):imports.append(n.module or '')
 if any('review_gate' in x for x in imports):fail(errors,'bootstrap imports normal gate')
 for token in ('REASONING_BUDGET = 10_240','Operator-Authorized-Gate-Change','root_of_trust','bootstrap_profile_hash','global-review.lock'):
  if token not in boot:fail(errors,'bootstrap missing '+token)
 if 'protocol_version < 2' in auth or 'return\n' in auth[:300]:pass
 for token in ('PROTOCOL_VERSION=4','validate_code_receipt','validate_bootstrap_receipt','review_profile_hash','requirements_manifest_hash'):
  if token not in auth:fail(errors,'authority verifier missing '+token)
 wf=read('payload/.github/workflows/platform-smoke.yml')
 got_ids=re.findall(r'^\s+- id:\s*([A-Za-z0-9-]+)\s*$',wf,re.M); got_labels=re.findall(r'^\s+label:\s*([^\s]+)\s*$',wf,re.M)
 if got_ids!=LANES:fail(errors,'hosted lane IDs changed')
 if got_labels!=LABELS:fail(errors,'hosted runner labels changed')
 if 'cancel-in-progress: false' not in wf or 'cancel-in-progress: true' in wf:fail(errors,'hosted cancellation policy unsafe')
 if re.search(r'^\s+push:\s*$',wf,re.M) or re.search(r'^\s+pull_request:\s*$',wf,re.M):fail(errors,'protected product workflow has automatic push/PR trigger')
 if 'needs: authorization' not in wf or 'protected-execution-authorization' not in wf:fail(errors,'hosted authorization does not precede product jobs')
 if '/${{ matrix.id }}/sokol-host' not in wf:fail(errors,'Sokol evidence not nested in lane bundle')
 for token in ('length == 20','status == "completed"','conclusion == "success"','make_publication_manifest.py'):
  if token not in wf:fail(errors,'hosted exact-20/provenance missing '+token)
 evidence=read('payload/tools/harness/evidence_schema_v2.py'); verifier=read('payload/tools/harness/verify_platform_evidence.py')
 for token in ('EXPECTED_FUSE_MANIFESTS','unexpected_failures','silent_skips','semantic_result_signature','deterministic_tree_index'):
  if token not in evidence:fail(errors,'evidence schema missing '+token)
 for token in ('source_files','sokol','result-manifest.json','verify_tree'):
  if token not in verifier:fail(errors,'evidence verifier missing '+token)
 installer=read('apply_update.py')
 for token in ('verify_package','Operator-Authorized-Gate-Change','bootstrap-root-of-trust.local.json','EXPECTED_BLOBS','CERTIFICATION.json'):
  if token not in installer:fail(errors,'installer missing '+token)
 if not (ROOT/'patches/generate_exact_patches.py').is_file() or not (ROOT/'patches/README.md').is_file():fail(errors,'patch material missing')
 for rel in ('docs/PROTOCOL-V4-CONTRACT-ADDENDUM.md','docs/FRESH-BOOTSTRAP-V4-ADDENDUM.md','docs/WORKFLOW-V4-ADDENDUM.md','docs/CHANGE-ISOLATION.md','docs/MIGRATION-PREFLIGHT-TEMPLATE.md'):
  if not (ROOT/rel).is_file():fail(errors,'documentation missing '+rel)

def run_checks(errors):
 py=[sys.executable,'-m','py_compile','apply_update.py','payload/tools/reviewer/review_gate.py','payload/tools/reviewer/legacy_bootstrap_gate.py','payload/tools/harness/evidence_schema_v2.py','payload/tools/harness/review_authority_v4.py','payload/tools/harness/verify_platform_evidence.py','payload/tools/validate_review_gate_v4.py','tests/test_review_gate_v4.py']
 r=subprocess.run(py,cwd=ROOT,capture_output=True,text=True)
 if r.returncode:fail(errors,'py_compile failed: '+r.stderr[-500:])
 r=subprocess.run(['bash','-n','payload/tools/harness/cleanup-hosted-runner-state.sh'],cwd=ROOT,capture_output=True,text=True)
 if r.returncode:fail(errors,'bash syntax failed')
 r=subprocess.run([sys.executable,'-m','unittest','-v','tests/test_review_gate_v4.py'],cwd=ROOT,capture_output=True,text=True)
 if r.returncode:fail(errors,'regression suite failed: '+r.stdout[-1000:]+r.stderr[-1000:])
 else:
  m=re.search(r'Ran (\d+) tests',r.stderr+r.stdout)
  if not m or int(m.group(1))<27:fail(errors,'regression suite count below 27')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);a=ap.parse_args();errors=[]
 m=manifest_check(errors);static_checks(errors);run_checks(errors)
 result={'schema_version':1,'audit_label':a.label,'baseline_commit':BASE,'ledger_sha256':LEDGER_SHA,'tree_sha256':m.get('tree_sha256') if isinstance(m,dict) else None,'gap_count':len(errors),'gaps':errors,'result':'ZERO_GAPS' if not errors else 'GAPS'}
 print(json.dumps(result,indent=2,sort_keys=True));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
