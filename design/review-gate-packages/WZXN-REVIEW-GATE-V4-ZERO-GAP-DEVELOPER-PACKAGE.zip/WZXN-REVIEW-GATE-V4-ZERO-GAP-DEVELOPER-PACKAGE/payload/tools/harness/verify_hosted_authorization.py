#!/usr/bin/env python3
from pathlib import Path
import argparse,json
from hosted_gate_authority import verify
ap=argparse.ArgumentParser(); ap.add_argument("--payload",required=True); ap.add_argument("--signature",required=True); ap.add_argument("--expected-sha",required=True); a=ap.parse_args()
body=verify(Path.cwd().resolve(),a.payload,a.signature,a.expected_sha); print(json.dumps({"status":"authorized","head_sha":body["head_sha"]},separators=(",",":")))
