#!/usr/bin/env python3
from pathlib import Path
import argparse,json
from hosted_gate_authority import make
ap=argparse.ArgumentParser(); ap.add_argument("--ttl-seconds",type=int,default=14400); a=ap.parse_args()
payload,sig,body=make(Path.cwd().resolve(),a.ttl_seconds)
print(json.dumps({"authorization_payload":payload,"authorization_signature":sig,"head_sha":body["head_sha"],"expires_at":body["expires_at"]},separators=(",",":"),sort_keys=True))
