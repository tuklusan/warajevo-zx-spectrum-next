Warajevo ZX Spectrum Next
Copyright (c) 2026 Supratim Sanyal, SANYALnet Labs, for new original project material.
New original material is licensed under GNU GPL v2 or later (GPL-2.0-or-later), as stated in LICENSE.txt.
Upstream Warajevo and third-party material retain their applicable copyrights and licenses.
See LICENSE.txt and NOTICE.md for complete terms and provenance.

# CR-0350 Current-Baseline Recovery Package

This is a snapshot of committed reviewer-gate and related workflow files at the tagged baseline. It does not replace the original certified redesign package or claim a new functional zero-gap review. Extraction and verification are safe; installation rewrites only the listed protected paths and requires explicit operator authorization. Run `python apply_update.py REPO --operator-authorized --verify-only` before any restore. The installer refuses a different HEAD, moved tag, changed Git object, or changed archive payload. Do not install onto a later commit.
