<!--
Warajevo ZX Spectrum Next
Copyright (c) 2026 Supratim Sanyal, SANYALnet Labs, for new original project material.
New original material is licensed under GNU GPL v2 or later (GPL-2.0-or-later), as stated in LICENSE.txt.
Upstream Warajevo and third-party material retain their applicable copyrights and licenses.
See LICENSE.txt and NOTICE.md for complete terms and provenance.
-->

# Project Workflow

## External Review Gate

Before any CR code is executed on a designated remote or hosted test system,
the exact committed snapshot must pass the independent CODE gate documented in
`design/review-gate.md`. Required documentation and post-test artifact
reviews are also mandatory. Serious findings are advisory to the developer but
may not be silently ignored; corrections or evidence-backed disputed
dispositions require a complete new review.

Normal CODE review is bound to the active CR, a clean committed current head,
exact requirement sources, and immutable Git-object evidence. Reviewer passes
discover candidates; only candidates that survive deterministic provenance
checks and hostile falsification become blockers. A new CODE attempt
invalidates the prior private receipt before review begins, and unresolved or
ambiguous authority remains fail-closed.

Before each review request, packet construction is its own hard gate. The
review map must express each requirement in a minimal but complete excerpt and
must point to the exact related implementation or document range. The packet
builder must prove that the requirement text, related excerpt, and any prior
diff refer to the same CR intent and immutable source objects. It must emit
separate full-source and excerpt hashes, bind a prior diff to its base/head
objects and ranges, and reject stale hashes, invalid ranges, path mismatches,
empty diffs, or omitted prior context before transport. A
`CODE-DISCOVERY OutputError` requires this packet-consistency check and map
regeneration before any retry; an unchanged packet must never be retried as a
substitute for fixing construction.

## Review Handle and Closure Ordering

The execution wrapper must return a bounded first response that preserves the
live session identifier even when command output is large. If wrapper output is
truncated or the outer handle is unavailable, do not restart the command:
recover by polling the durable reviewer lock/state and classify the observation
as indeterminate until that state is terminal. A reviewer packet may never be
started in parallel with another packet.

A CR and its preflight record must remain active while any implementation,
evidence, or final review gate is pending. Before each review, verify that the
tracker and preflight statuses identify the same active CR. Only after the
final DOCUMENTATION review returns PASS may the closure record be completed
and both statuses transition to CLOSED. A refused or failed review leaves the
CR active and recoverable.

## Migration Pre-Development Gate

Before editing implementation artifacts for every CR or other tracked work item,
create `design/cr-preflight/CR-NNNN.md`. The record must enumerate every
functional aspect in scope, including normal behavior, edge cases, state
transitions, timing/bus effects, data formats, error behavior, UI or external
contract effects, tests, and compatibility implications.

The record must identify the architecture/task authority and the upstream
repository commit plus every source file, symbol, or search domain examined.
Each discovered upstream behavior must have an explicit disposition:
`IMPLEMENT_NOW`, `DEFERRED_WITH_CR`, `NOT_APPLICABLE`, or
`REIMPLEMENTED_DIFFERENTLY` with an evidence-backed reason.

Before implementation begins, repeat the upstream discovery scan using broader
symbols and neighboring control paths. The preflight exit is valid only when
the record states `Status: APPROVED_FOR_IMPLEMENTATION` and its zero-gap scan
lists no undispositioned behavior. CODE review and remote/hosted execution are
blocked until this tracked record exists for the active CR.

## Root Rule

Never create any project item or artifact above the project directory.

Always create, edit, store, and manage project artifacts within the project
directory tree.

## Local Machine Rule

Never build or test on this local machine.

This local machine is for editing source, documents, workflow files, issue
records, and other development artifacts only.

## Remote Build and Test Rule

All build, test, log-capture, trace-capture, and similar execution activity
must run only on the approved remote test machines.

GitHub-hosted runners used by this repository's tracked workflows are approved
remote build and test machines.

All pulled-back logs, traces, test results, screenshots, and similar outputs
must be stored under:

```text
test-artefacts/
```

The public harness contract for those machines lives in
`test-artefacts/README.md`, and the tracked shared harness entry points live in
`tools/harness/`.

The active local lab registry contains Linux `192.168.4.76` and Windows 10
`192.168.4.75`. Any SSH failure must be recorded as an environmental result and
must not be treated as evidence that the software failed. The complete hosted
runner matrix remains required for multi-platform proof regardless of lab
availability, and every configured hosted macOS lane should be exercised when
capacity permits. Retired local hosts are not valid harness targets.

Hosted-runner waiting is terminal-state based. Use one run for the exact
published commit with `fail-fast: false`; wait for every configured lane,
including queued or slow lanes. Never cancel or replace a live run and never
classify a queued lane as failed. Only terminal GitHub job conclusions may
feed the publication gate.

External reviewer calls may be slow. The review gate permits a request to wait
up to the one-hour review deadline and clamps each transport timeout to the
remaining deadline. Do not classify a healthy slow call as failed at an
arbitrary shorter interval; only a terminal response, retry exhaustion, or
overall deadline exhaustion ends the review.

Completed matrix evidence may be reused for a later instrumentation-only
correction when the prior run reached terminal state, passed the matrix's
product/build/test acceptance criteria, and is bound to the exact commit.
The active CR must record the prior run ID, commit, correction scope, and
reason for reuse. Instrumentation-only corrections include manifest generation,
log forwarding, screenshot or trace inspection, and publication bookkeeping;
they must not alter product source, tests, build configuration, runner labels,
or lane execution semantics. Any such product or execution change requires a
fresh complete matrix run. An incomplete, queued, cancelled, or failed matrix is never eligible for this exception.

The hosted matrix has a pre-matrix deep-housekeeping gate. It may delete only
older terminal completed `platform-smoke` runs for the same ref; it MUST NOT
cancel, replace, or delete a queued/in-progress run. Every matrix lane clears
only generated workspace residue before execution.

Hosted publication acceptance is exact-matrix based: all 20 configured lane IDs must reach terminal `success` for the exact commit. Intel and ARM macOS lanes remain explicitly required within that exact set. Local or remote lab evidence supplements diagnosis but never substitutes for a hosted lane.

## Private Local Artifacts

## Local Soak Validation Mode

The temporary hosted-only exception has been withdrawn by operator direction.
Local test-machine soaks are enabled again. Keep the local test-machine
harness, machine definitions, SSH credentials, screenshot paths, and approved
directory restrictions unchanged. GitHub-hosted validation remains required
and must still await every configured lane; local results supplement rather
than silently replace hosted evidence.

Private local-only material still belongs inside the project directory.

For the difficult-media regression corpus, use:

```text
WZSN-PRIVATE-TEST-MEDIA/
```

within the repository root. Only its public guidance files are committed. The
private media files inside it remain local-only and ignored by Git.

## Public Repository Rule

If an artifact is intended to stay private, the repository must enforce that
privacy through Git ignore rules, validation rules, and release/packaging
guards rather than by placing the artifact outside the project directory.

## Remote Machine Directory Rule

## Harness Lock

Every working local, hosted, remote-build, remote-test, screenshot, cleanup,
transport, and parser harness is tracked by
`tools/harness/harness-lock.json`. The lock is mandatory and requires explicit
operator authorization before any listed harness or its governing gate is
modified. A proven harness must remain unchanged unless a concrete blocker is
identified and the authorization is recorded in the active CR evidence.

Remote build or test sessions must stay within the approved per-machine project
directories defined in `test-artefacts/README.md`.

## Remote Validation Ordering Rule

Every remote smoke invocation must verify the exact published CODE PASS
authority before SSH synchronization or any remote build/test command begins.
If that precondition is absent, stale, or no longer matches the tracker or
requirements, the harness writes a machine-readable session record with
`classification: review_pending` and `remote_execution_started: false`. This
is a workflow-state result, not an SSH or lab-machine availability result.
Only after the precondition passes may SSH reachability, synchronization,
build/test, artifact transport, and evidence outcomes be classified.

## PowerShell Parser-First Rule

Whenever a PowerShell command is about to be executed on the local machine or
on a remote Windows machine, the exact command text must be passed through a
parser first.

Use the tracked parser helper:

```text
tools/Test-PowerShellSyntax.ps1
```

The parser check must succeed before the actual PowerShell command is executed.

## Hosted Runner Evidence Rule

Every hosted matrix lane must complete its build and tests, emit its
machine-readable result manifest, and upload the complete lane bundle. The
The publication gate downloads and re-verifies every bundle before accepting the run.
If a later correction only repairs that instrumentation after a complete
passing matrix, reuse is allowed only under the completed-evidence rule above.
Screenshots and traces are inspected by hash when produced; visual
capture is required for a lane only when that platform/application supports an
interactive host. Unsupported capture must be recorded explicitly, never
silently treated as a passing visual result.

## Windows Debugger Requirement

Windows 10 and Windows 11 validation machines must have the Windows SDK
Debugging Tools installed. The required debugger entry points are `cdb.exe`
and `windbg.exe`; the harness searches the Windows Kits 10 Debuggers tree,
including its `x64`, `x86`, `arm`, and `arm64` subdirectories. These tools are
used for native crash capture and stack analysis when a compiler-specific
failure needs diagnosis. Install them from Microsoft's official Windows SDK
or Windows SDK Debugging Tools package; the executables themselves are not
copied into or redistributed by this repository.

## Review protocol v4 workflow correction

This section supersedes conflicting earlier hosted acceptance/cancellation wording.

1. Every tracked mandatory review requires one active CR and matching approved preflight. `Review-Base` is mandatory and is normally a stable tag created at the committed preflight baseline. Gate/harness/governance edits additionally require `Operator-Authorized-Gate-Change: YES`.
2. CODE PASS -> required DOCUMENTATION PASS -> publish exact reviewed commit -> generate short-lived hosted authorization -> dispatch `platform-smoke` once for that exact commit -> wait for every lane to reach terminal success -> retain signed publication evidence -> TEST_ARTIFACT second opinion.
3. `platform-smoke` is protected execution and is dispatch-only. Its exact 20 lane IDs/labels are mandatory. There is no local/remote substitution for a hosted lane in publication acceptance.
4. A queued/in-progress hosted run is never cancelled or replaced by housekeeping. Housekeeping may delete only older terminal completed runs and generated workspace residue.
5. Windows 11 and macOS platform breadth is supplied by the unchanged hosted matrix; retired local-lab Windows-11/Big-Sur machines remain retired and are not exceptions/expected failures.
6. Signed publication provenance binds workflow run ID, exact commit/build ID, workflow blob, exact expected lanes, terminal jobs and artifacts. TEST_ARTIFACT verifies that provenance before semantic review.

7. Gate protocol/root-of-trust migration is applied atomically under one operator-authorized maintenance CR because partial installation would mismatch receipts, hosted authorization, evidence schema and verifier authority. After cutover, independent tuning or policy changes return to ordinary small CRs.
