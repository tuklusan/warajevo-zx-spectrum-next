#!/usr/bin/env python3
"""Warajevo ZX Spectrum Next
Copyright (c) 2026 Supratim Sanyal, SANYALnet Labs, for new original project material.
New original material is licensed under GNU GPL v2 or later (GPL-2.0-or-later), as stated in LICENSE.txt.
Upstream Warajevo and third-party material retain their applicable copyrights and licenses.
See LICENSE.txt and NOTICE.md for complete terms and provenance.
"""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=pathlib.Path)
    parser.add_argument("--operator-authorized", action="store_true")
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    if not args.operator_authorized:
        raise SystemExit("operator authorization required")
    repo = args.repo.resolve()
    archive = pathlib.Path(__file__).resolve().parent
    manifest_bytes = (archive / "PACKAGE-MANIFEST.json").read_bytes()
    cert = json.loads((archive / "CERTIFICATION.json").read_bytes())
    if sha(manifest_bytes) != cert["manifest_sha256"]:
        raise SystemExit("manifest certificate mismatch")
    manifest = json.loads(manifest_bytes)
    def git(*parts):
        return subprocess.check_output(["git", *parts], cwd=repo).strip().decode()
    if git("rev-parse", "HEAD") != manifest["base_commit"]:
        raise SystemExit("wrong HEAD for certified recovery")
    if git("rev-parse", manifest["base_tag"]) != manifest["base_commit"]:
        raise SystemExit("base tag mismatch")
    preflight = subprocess.check_output(["git", "show", "HEAD:design/cr-preflight/CR-0350.md"], cwd=repo)
    if b"Operator-Authorized-Gate-Change: YES" not in preflight:
        raise SystemExit("approved CR preflight missing")
    files = {}
    for name, meta in manifest["files"].items():
        path = pathlib.PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts:
            raise SystemExit("unsafe payload path")
        data = (archive / "payload" / name).read_bytes()
        if sha(data) != meta["sha256"] or len(data) != meta["bytes"]:
            raise SystemExit("payload mismatch: " + name)
        committed = subprocess.check_output(["git", "show", "HEAD:" + name], cwd=repo)
        if committed != data:
            raise SystemExit("Git object mismatch: " + name)
        files[name] = data
    if args.verify_only:
        print("CERTIFIED PACKAGE VERIFIED", manifest["base_commit"], len(files))
        return
    for name, data in files.items():
        target = repo / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print("CERTIFIED PACKAGE RESTORED", len(files))

if __name__ == "__main__":
    main()
